import express, { type NextFunction, type Request, type Response } from 'express';
import { getApp, getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';

const PORT = Number(process.env.PORT || 3000);
const ADMIN_EMAIL = 'oruc71049@gmail.com';

const ROOT_DIR = process.cwd();
const CONFIG_PATH = path.resolve(ROOT_DIR, 'firebase-applet-config.json');
const UPLOAD_APK_DIR = path.resolve(ROOT_DIR, 'uploads', 'apks');
const UPLOAD_MEDIA_DIR = path.resolve(ROOT_DIR, 'uploads', 'media');

fs.mkdirSync(UPLOAD_APK_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_MEDIA_DIR, { recursive: true });

interface FirebaseAppletConfig {
  projectId: string;
}

function loadFirebaseProjectId(): string {
  const raw = fs.readFileSync(CONFIG_PATH, 'utf-8');
  const parsed = JSON.parse(raw) as FirebaseAppletConfig;
  if (!parsed.projectId) {
    throw new Error('Missing projectId in firebase-applet-config.json');
  }
  return parsed.projectId;
}

const projectId = loadFirebaseProjectId();
const adminApp = getApps().length ? getApp() : initializeApp({ projectId });
const adminAuth = getAuth(adminApp);

interface AuthenticatedRequest extends Request {
  adminUid?: string;
  adminEmail?: string;
}

async function verifyAdminFromHeader(authHeader: string | undefined): Promise<{
  ok: boolean;
  status: number;
  error?: string;
  uid?: string;
  email?: string;
  emailVerified?: boolean;
  provider?: string;
}> {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return { ok: false, status: 401, error: 'Authentication token required.' };
  }
  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    return { ok: false, status: 401, error: 'Empty authentication token.' };
  }
  try {
    const decoded = await adminAuth.verifyIdToken(token);
    const email = typeof decoded.email === 'string' ? decoded.email.toLowerCase() : '';
    const provider = decoded.firebase?.sign_in_provider || '';
    const isVerified = decoded.email_verified === true;

    if (!isVerified || provider !== 'google.com' || email !== ADMIN_EMAIL) {
      return {
        ok: false,
        status: 403,
        error: 'Yalnız təsdiqlənmiş oruc71049@gmail.com Google hesabı administrator hüququna malikdir.',
        uid: decoded.uid,
        email,
        emailVerified: isVerified,
        provider,
      };
    }

    return {
      ok: true,
      status: 200,
      uid: decoded.uid,
      email,
      emailVerified: isVerified,
      provider,
    };
  } catch (err) {
    console.error('Admin verification failed:', err);
    return { ok: false, status: 401, error: 'Token doğrulanmadı.' };
  }
}

async function requireAdmin(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const result = await verifyAdminFromHeader(req.headers.authorization);
  if (!result.ok) {
    res.status(result.status).json({ error: result.error });
    return;
  }
  req.adminUid = result.uid;
  req.adminEmail = result.email;
  next();
}

function sanitizeBaseName(originalName: string): string {
  const base = path.basename(originalName, path.extname(originalName));
  const cleaned = base.replace(/[^a-zA-Z0-9_-]/g, '_').replace(/_+/g, '_').slice(0, 60);
  return cleaned || 'package';
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

const apkUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_APK_DIR),
    filename: (_req, file, cb) => {
      const safeBase = sanitizeBaseName(file.originalname);
      const unique = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      cb(null, `${unique}_${safeBase}.apk`);
    },
  }),
  limits: { fileSize: 200 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (ext !== '.apk') {
      cb(new Error('Yalnız .apk formatında fayllar yüklənə bilər.'));
      return;
    }
    cb(null, true);
  },
});

const mediaUpload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, UPLOAD_MEDIA_DIR),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      const safeBase = sanitizeBaseName(file.originalname);
      const unique = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
      cb(null, `${unique}_${safeBase}${ext}`);
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    if (!['.png', '.jpg', '.jpeg', '.webp'].includes(ext)) {
      cb(new Error('Yalnız PNG, JPG və ya WEBP şəkillər qəbul olunur.'));
      return;
    }
    cb(null, true);
  },
});

const SAFE_APK_FILENAME_RE = /^[a-zA-Z0-9._-]+\.apk$/;
const SAFE_MEDIA_FILENAME_RE = /^[a-zA-Z0-9._-]+\.(png|jpg|jpeg|webp)$/;

const ZIP_LOCAL_HEADER = 0x04034b50; // PK\x03\x04
const ZIP_EOCD_SIG = 0x06054b50; // PK\x05\x06
const ZIP_CD_SIG = 0x02014b50; // PK\x01\x02
const MAX_APK_BYTES = 200 * 1024 * 1024;

function verifyAndroidApkOnDisk(filePath: string, fileSize: number): { valid: boolean; error?: string } {
  if (fileSize <= 22) {
    return { valid: false, error: 'Fayl ölçüsü etibarlı Android APK strukturu üçün çox kiçikdir.' };
  }
  if (fileSize > MAX_APK_BYTES) {
    return { valid: false, error: 'APK faylı maksimum 200 MB ola bilər.' };
  }

  let fd: number | null = null;
  try {
    fd = fs.openSync(filePath, 'r');

    const head = Buffer.alloc(4);
    fs.readSync(fd, head, 0, 4, 0);
    if (head.readUInt32LE(0) !== ZIP_LOCAL_HEADER) {
      return {
        valid: false,
        error: 'Yüklənən fayl etibarlı Android APK (ZIP arxivi) deyil. Saxta və ya zədələnmiş fayl rədd edildi.',
      };
    }

    const tailSize = Math.min(fileSize, 65557);
    const tailOffset = fileSize - tailSize;
    const tail = Buffer.alloc(tailSize);
    fs.readSync(fd, tail, 0, tailSize, tailOffset);

    let eocdPos = -1;
    for (let i = tail.length - 22; i >= 0; i--) {
      if (tail.readUInt32LE(i) === ZIP_EOCD_SIG) {
        const commentLen = tail.readUInt16LE(i + 20);
        if (i + 22 + commentLen === tail.length) {
          eocdPos = i;
          break;
        }
      }
    }

    if (eocdPos === -1) {
      return { valid: false, error: 'APK arxivinin mərkəzi kataloqu tapılmadı.' };
    }

    const cdSize = tail.readUInt32LE(eocdPos + 12);
    const cdOffset = tail.readUInt32LE(eocdPos + 16);
    if (cdSize === 0 || cdSize > 32 * 1024 * 1024 || cdOffset + cdSize > fileSize) {
      return { valid: false, error: 'APK arxiv strukturu etibarsızdır.' };
    }

    const cd = Buffer.alloc(cdSize);
    fs.readSync(fd, cd, 0, cdSize, cdOffset);

    let pos = 0;
    let hasManifest = false;
    while (pos + 46 <= cd.length) {
      if (cd.readUInt32LE(pos) !== ZIP_CD_SIG) break;
      const nameLen = cd.readUInt16LE(pos + 28);
      const extraLen = cd.readUInt16LE(pos + 30);
      const commentLen = cd.readUInt16LE(pos + 32);
      if (pos + 46 + nameLen > cd.length) break;

      const entryName = cd.subarray(pos + 46, pos + 46 + nameLen).toString('utf-8');
      if (entryName === 'AndroidManifest.xml') {
        hasManifest = true;
        break;
      }
      pos += 46 + nameLen + extraLen + commentLen;
    }

    if (!hasManifest) {
      return {
        valid: false,
        error: 'Faylın daxilində AndroidManifest.xml tapılmadı. Yalnız həqiqi APK paketləri qəbul olunur.',
      };
    }

    return { valid: true };
  } catch {
    return { valid: false, error: 'APK faylının strukturu oxuna bilmədi.' };
  } finally {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch {
        // ignore close failure
      }
    }
  }
}

function verifyImageMagicBytes(filePath: string): boolean {
  let fd: number | null = null;
  try {
    fd = fs.openSync(filePath, 'r');
    const buf = Buffer.alloc(12);
    const bytesRead = fs.readSync(fd, buf, 0, 12, 0);
    if (bytesRead < 3) return false;

    const isPng =
      bytesRead >= 8 &&
      buf[0] === 0x89 &&
      buf[1] === 0x50 &&
      buf[2] === 0x4e &&
      buf[3] === 0x47 &&
      buf[4] === 0x0d &&
      buf[5] === 0x0a &&
      buf[6] === 0x1a &&
      buf[7] === 0x0a;
    const isJpeg = buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff;
    const isWebp =
      bytesRead >= 12 &&
      buf.subarray(0, 4).toString('ascii') === 'RIFF' &&
      buf.subarray(8, 12).toString('ascii') === 'WEBP';

    return isPng || isJpeg || isWebp;
  } catch {
    return false;
  } finally {
    if (fd !== null) {
      try {
        fs.closeSync(fd);
      } catch {
        // ignore
      }
    }
  }
}

function safeUnlink(filePath: string): void {
  try {
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch {
    // ignore cleanup failure
  }
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  // Server-side administrator identity verification endpoint
  app.get('/api/auth/verify-admin', async (req: Request, res: Response) => {
    const result = await verifyAdminFromHeader(req.headers.authorization);
    if (!result.ok) {
      res.status(result.status).json({
        isAdmin: false,
        error: result.error,
      });
      return;
    }
    res.json({
      isAdmin: true,
      uid: result.uid,
      email: result.email,
      emailVerified: result.emailVerified,
      provider: result.provider,
    });
  });

  // Upload APK (Admin only)
  app.post('/api/upload/apk', requireAdmin, (req: Request, res: Response) => {
    apkUpload.single('apk')(req, res, (err: unknown) => {
      if (err) {
        const message = err instanceof Error ? err.message : 'APK yükləmə xətası.';
        res.status(400).json({ error: message });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'APK faylı seçilməyib.' });
        return;
      }

      const verification = verifyAndroidApkOnDisk(req.file.path, req.file.size);
      if (!verification.valid) {
        safeUnlink(req.file.path);
        res.status(400).json({ error: verification.error || 'Etibarsız APK faylı.' });
        return;
      }

      const fileName = req.file.filename;
      res.json({
        apkFileName: fileName,
        apkDownloadUrl: `/api/apks/download/${encodeURIComponent(fileName)}`,
        fileSizeBytes: req.file.size,
        fileSizeLabel: formatBytes(req.file.size),
      });
    });
  });

  // Upload Icon or Screenshot Image (Admin only)
  app.post('/api/upload/media', requireAdmin, (req: Request, res: Response) => {
    mediaUpload.single('image')(req, res, (err: unknown) => {
      if (err) {
        const message = err instanceof Error ? err.message : 'Şəkil yükləmə xətası.';
        res.status(400).json({ error: message });
        return;
      }
      if (!req.file) {
        res.status(400).json({ error: 'Şəkil faylı seçilməyib.' });
        return;
      }

      if (!verifyImageMagicBytes(req.file.path)) {
        safeUnlink(req.file.path);
        res.status(400).json({ error: 'Faylın məzmunu etibarlı PNG, JPG və ya WEBP şəkli deyil.' });
        return;
      }

      res.json({
        fileName: req.file.filename,
        url: `/api/media/${encodeURIComponent(req.file.filename)}`,
      });
    });
  });

  // Check APK availability cleanly before counting downloads
  app.head('/api/apks/download/:filename', (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_APK_FILENAME_RE.test(filename)) {
      res.status(400).end();
      return;
    }
    const resolved = path.resolve(UPLOAD_APK_DIR, filename);
    if (!resolved.startsWith(UPLOAD_APK_DIR + path.sep) || !fs.existsSync(resolved)) {
      res.status(404).end();
      return;
    }
    const stat = fs.statSync(resolved);
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.setHeader('Content-Length', String(stat.size));
    res.status(200).end();
  });

  // Download APK (Public store download)
  app.get('/api/apks/download/:filename', (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_APK_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış fayl adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_APK_DIR, filename);
    if (!resolved.startsWith(UPLOAD_APK_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    if (!fs.existsSync(resolved)) {
      res.status(404).json({ error: 'APK faylı serverdə tapılmadı və ya silinib.' });
      return;
    }

    const requestedName = typeof req.query.name === 'string' ? req.query.name : filename;
    const cleanDownloadName = requestedName.replace(/[^a-zA-Z0-9._-]/g, '_');
    const finalName = cleanDownloadName.endsWith('.apk') ? cleanDownloadName : `${cleanDownloadName}.apk`;

    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    res.download(resolved, finalName);
  });

  // Delete APK file from server (Admin only)
  app.delete('/api/apks/:filename', requireAdmin, (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_APK_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış fayl adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_APK_DIR, filename);
    if (!resolved.startsWith(UPLOAD_APK_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    safeUnlink(resolved);
    res.json({ deleted: true });
  });

  // Delete media image from server (Admin only)
  app.delete('/api/media/:filename', requireAdmin, (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_MEDIA_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış şəkil adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_MEDIA_DIR, filename);
    if (!resolved.startsWith(UPLOAD_MEDIA_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    safeUnlink(resolved);
    res.json({ deleted: true });
  });

  // Serve uploaded media images
  app.get('/api/media/:filename', (req: Request, res: Response) => {
    const filename = String(req.params.filename || '');
    if (!SAFE_MEDIA_FILENAME_RE.test(filename)) {
      res.status(400).json({ error: 'Yanlış şəkil adı.' });
      return;
    }
    const resolved = path.resolve(UPLOAD_MEDIA_DIR, filename);
    if (!resolved.startsWith(UPLOAD_MEDIA_DIR + path.sep)) {
      res.status(400).json({ error: 'İcazəsiz yol.' });
      return;
    }
    if (!fs.existsSync(resolved)) {
      res.status(404).json({ error: 'Şəkil tapılmadı.' });
      return;
    }
    res.sendFile(resolved);
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(ROOT_DIR, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Oruc App Store server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
