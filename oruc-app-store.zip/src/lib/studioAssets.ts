import heroBannerImg from '../assets/images/hero_apk_storefront_1795271507372.jpg';
import iconAtlasNotesImg from '../assets/images/app_icon_atlas_notes_1795271507869.jpg';
import iconKinetikFitImg from '../assets/images/app_icon_kinetik_fit_1795271507589.jpg';
import iconVeloxPlayerImg from '../assets/images/app_icon_velox_player_1795271507475.jpg';
import screenshotShowcaseImg from '../assets/images/app_screenshot_showcase_1795271508023.jpg';

export const STUDIO_ASSETS = {
  heroBanner: heroBannerImg,
  screenshotShowcase: screenshotShowcaseImg,
  icons: [
    {
      label: 'Qeyd və Məhsuldarlıq',
      url: iconAtlasNotesImg,
    },
    {
      label: 'Sağlamlıq və Kinetika',
      url: iconKinetikFitImg,
    },
    {
      label: 'Audio və Media',
      url: iconVeloxPlayerImg,
    },
  ],
} as const;
