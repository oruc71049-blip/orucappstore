import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Component, type ErrorInfo, type ReactNode } from 'react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends Component<Props, State> {
  state: State = {
    hasError: false,
    message: '',
  };

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      message: error.message || 'Gözlənilməz xəta baş verdi.',
    };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    console.error('ErrorBoundary caught error:', error, info);
  }

  render() {
    if (this.state.hasError) {
      let friendly = 'Sistemdə xəta baş verdi. Zəhmət olmasa səhifəni yeniləyin.';
      if (this.state.message.includes('Missing or insufficient permissions')) {
        friendly = 'Bu əməliyyat üçün icazəniz yoxdur və ya hesab təsdiqlənməyib.';
      } else if (this.state.message.includes('Quota exceeded')) {
        friendly = 'Gündəlik verilənlər bazası limiti dolub. Sabah yenidən cəhd edin.';
      }

      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
          <div className="max-w-md w-full bg-white border border-slate-200 rounded-xl p-8 text-center">
            <div className="w-12 h-12 rounded-xl bg-red-50 text-red-600 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-semibold text-slate-900 mb-2">Əməliyyat dayandırıldı</h2>
            <p className="text-sm text-slate-600 mb-6">{friendly}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap"
            >
              <RefreshCw className="w-4 h-4" />
              Səhifəni yenilə
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
