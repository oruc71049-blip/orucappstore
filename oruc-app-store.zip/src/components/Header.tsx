import { Check, LogIn, LogOut, ShieldCheck, User as UserIcon } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';

export type ActiveRoute = 'store' | 'app' | 'admin' | 'trust';

interface HeaderProps {
  activeRoute: ActiveRoute;
  onNavigate: (route: ActiveRoute, appId?: string) => void;
  onSelectCategorySection: () => void;
}

export function Header({ activeRoute, onNavigate, onSelectCategorySection }: HeaderProps) {
  const { user, profile, isAdmin, signingIn, signInWithGoogle, signOut, updateProfileName } =
    useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [editingName, setEditingName] = useState(false);
  const [nameInput, setNameInput] = useState('');
  const [savingName, setSavingName] = useState(false);

  const [avatarError, setAvatarError] = useState(false);

  const displayName =
    profile?.displayName || user?.displayName || user?.email?.split('@')[0] || 'Hesabım';
  const avatarUrl = !avatarError ? profile?.photoURL || user?.photoURL || '' : '';

  const handleOpenNameEdit = () => {
    setNameInput(displayName);
    setEditingName(true);
  };

  const handleSaveName = async () => {
    if (!nameInput.trim()) return;
    setSavingName(true);
    try {
      await updateProfileName(nameInput);
      setEditingName(false);
    } finally {
      setSavingName(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Single-element brand wordmark */}
        <button
          type="button"
          onClick={() => onNavigate('store')}
          className="font-display text-xl font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded"
        >
          Oruc App Store
        </button>

        {/* Zone 2: Concise single-line navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-600">
          <button
            type="button"
            onClick={() => onNavigate('store')}
            className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-900 ${
              activeRoute === 'store'
                ? 'text-slate-900 underline decoration-blue-600 decoration-2 underline-offset-8'
                : ''
            }`}
          >
            Kataloq
          </button>
          <button
            type="button"
            onClick={() => {
              onNavigate('store');
              onSelectCategorySection();
            }}
            className="whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-900"
          >
            Kateqoriyalar
          </button>
          <button
            type="button"
            onClick={() => onNavigate('trust')}
            className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-900 ${
              activeRoute === 'trust'
                ? 'text-slate-900 underline decoration-blue-600 decoration-2 underline-offset-8'
                : ''
            }`}
          >
            Təhlükəsizlik
          </button>
          {isAdmin ? (
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className={`whitespace-nowrap shrink-0 py-1 transition-colors hover:text-slate-900 inline-flex items-center gap-1.5 ${
                activeRoute === 'admin'
                  ? 'text-blue-700 underline decoration-blue-600 decoration-2 underline-offset-8'
                  : 'text-slate-700'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-blue-600" />
              Admin Paneli
            </button>
          ) : null}
        </nav>

        {/* Zone 3: Single primary action */}
        <div className="relative flex items-center shrink-0">
          {!user ? (
            <button
              type="button"
              disabled={signingIn}
              onClick={() => void signInWithGoogle()}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors whitespace-nowrap shrink-0 disabled:opacity-60"
            >
              <LogIn className="w-4 h-4" />
              {signingIn ? 'Giriş edilir...' : 'Daxil ol / Qeydiyyat'}
            </button>
          ) : (
            <div>
              <button
                type="button"
                onClick={() => setMenuOpen((prev) => !prev)}
                className="inline-flex items-center gap-2.5 px-3 py-1.5 text-sm font-medium text-slate-800 bg-slate-100 hover:bg-slate-200/80 rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                {avatarUrl ? (
                  <img
                    src={avatarUrl}
                    alt={displayName}
                    referrerPolicy="no-referrer"
                    onError={() => setAvatarError(true)}
                    className="w-6 h-6 rounded-full object-cover border border-slate-200 shrink-0"
                  />
                ) : (
                  <UserIcon className="w-4 h-4 text-slate-600" />
                )}
                <span className="max-w-[140px] truncate">{displayName}</span>
              </button>

              {menuOpen ? (
                <div className="absolute right-0 mt-2 w-72 bg-white border border-slate-200 rounded-xl shadow-lg p-4 z-50">
                  <div className="pb-3 border-b border-slate-100 flex items-center gap-3">
                    {avatarUrl ? (
                      <img
                        src={avatarUrl}
                        alt={displayName}
                        referrerPolicy="no-referrer"
                        onError={() => setAvatarError(true)}
                        className="w-10 h-10 rounded-full object-cover border border-slate-200 shrink-0"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0">
                        <UserIcon className="w-5 h-5 text-slate-500" />
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-slate-900 truncate">{displayName}</p>
                      <p className="text-xs text-slate-500 truncate mt-0.5">{user.email}</p>
                      {isAdmin ? (
                        <p className="text-xs font-medium text-blue-700 mt-1">
                          Mağaza Administratoru
                        </p>
                      ) : null}
                    </div>
                  </div>

                  {editingName ? (
                    <div className="py-3 border-b border-slate-100 space-y-2">
                      <label className="block text-xs font-medium text-slate-600">
                        Görünən adınız
                      </label>
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={nameInput}
                          onChange={(e) => setNameInput(e.target.value)}
                          maxLength={80}
                          className="flex-1 px-2.5 py-1.5 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                        />
                        <button
                          type="button"
                          disabled={savingName}
                          onClick={() => void handleSaveName()}
                          className="p-2 bg-blue-700 text-white rounded-lg hover:bg-blue-800 disabled:opacity-50"
                          aria-label="Yadda saxla"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="py-2 space-y-1">
                      <button
                        type="button"
                        onClick={handleOpenNameEdit}
                        className="w-full text-left px-2.5 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-lg transition-colors"
                      >
                        Adı redaktə et
                      </button>
                      {isAdmin ? (
                        <button
                          type="button"
                          onClick={() => {
                            setMenuOpen(false);
                            onNavigate('admin');
                          }}
                          className="w-full text-left px-2.5 py-2 text-sm text-blue-700 font-medium hover:bg-blue-50 rounded-lg transition-colors md:hidden"
                        >
                          Admin Paneli
                        </button>
                      ) : null}
                      <button
                        type="button"
                        onClick={() => {
                          setMenuOpen(false);
                          onNavigate('trust');
                        }}
                        className="w-full text-left px-2.5 py-2 text-sm text-slate-700 hover:bg-slate-50 rounded-lg transition-colors md:hidden"
                      >
                        Təhlükəsizlik qaydaları
                      </button>
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setMenuOpen(false);
                      void signOut();
                    }}
                    className="w-full mt-1 flex items-center gap-2 px-2.5 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                    Hesabdan çıx
                  </button>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
