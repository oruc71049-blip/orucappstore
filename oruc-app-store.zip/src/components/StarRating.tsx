import { Star } from 'lucide-react';

interface StarRatingDisplayProps {
  rating: number;
  size?: 'sm' | 'md';
  showNumeric?: boolean;
  reviewCount?: number;
}

export function StarRatingDisplay({
  rating,
  size = 'sm',
  showNumeric = true,
  reviewCount,
}: StarRatingDisplayProps) {
  const iconClass = size === 'md' ? 'w-4 h-4' : 'w-3.5 h-3.5';
  const rounded = Math.round(rating);

  return (
    <div className="inline-flex items-center gap-1.5">
      <div className="inline-flex items-center gap-0.5" aria-label={`${rating} / 5 ulduz`}>
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`${iconClass} ${
              star <= rounded
                ? 'fill-amber-500 text-amber-500'
                : 'fill-slate-100 text-slate-300'
            }`}
          />
        ))}
      </div>
      {showNumeric ? (
        <span className="text-xs font-medium text-slate-700 tabular-nums">
          {rating > 0 ? rating.toFixed(1) : '0.0'}
          {typeof reviewCount === 'number' ? (
            <span className="text-slate-400 font-normal"> ({reviewCount})</span>
          ) : null}
        </span>
      ) : null}
    </div>
  );
}

interface StarRatingInputProps {
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

export function StarRatingInput({ value, onChange, disabled = false }: StarRatingInputProps) {
  return (
    <div className="inline-flex items-center gap-1" role="radiogroup" aria-label="Ulduz qiyməti seçin">
      {[1, 2, 3, 4, 5].map((star) => {
        const active = star <= value;
        return (
          <button
            key={star}
            type="button"
            disabled={disabled}
            onClick={() => onChange(star)}
            aria-checked={value === star}
            role="radio"
            aria-label={`${star} ulduz`}
            className="p-1.5 rounded-lg hover:bg-slate-100 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 disabled:opacity-50"
          >
            <Star
              className={`w-6 h-6 transition-colors ${
                active ? 'fill-amber-500 text-amber-500' : 'fill-slate-100 text-slate-300'
              }`}
            />
          </button>
        );
      })}
      <span className="ml-2 text-sm font-medium text-slate-700 tabular-nums">{value} / 5</span>
    </div>
  );
}
