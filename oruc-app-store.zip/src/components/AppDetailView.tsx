import type { QueryDocumentSnapshot } from 'firebase/firestore';
import {
  AlertCircle,
  ArrowLeft,
  CheckCircle2,
  Download,
  Flag,
  Lock,
  ShieldCheck,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import {
  adminDeleteReview,
  deleteOwnReview,
  fetchReviewsPage,
  recordDownloadAndTrigger,
  submitOrUpdateReview,
  submitReport,
  subscribeApp,
  subscribeUserDownloadReceipt,
  subscribeUserOwnReview,
} from '../services/storeService';
import {
  BLUEPRINT_LIMITS,
  REPORT_REASONS,
  type AppListing,
  type AppReview,
  type DownloadReceipt,
  type ReportReason,
} from '../types/store';
import { SafeImage } from './SafeImage';
import { StarRatingDisplay, StarRatingInput } from './StarRating';

interface AppDetailViewProps {
  appId: string;
  onBack: () => void;
}

const REVIEWS_PAGE_SIZE = 8;

export function AppDetailView({ appId, onBack }: AppDetailViewProps) {
  const { user, profile, isAdmin, signInWithGoogle } = useAuth();
  const [app, setApp] = useState<AppListing | null>(null);
  const [loadingApp, setLoadingApp] = useState(true);
  const [reviews, setReviews] = useState<AppReview[]>([]);
  const [reviewsCursor, setReviewsCursor] = useState<QueryDocumentSnapshot | null>(null);
  const [hasMoreReviews, setHasMoreReviews] = useState(false);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [loadingMoreReviews, setLoadingMoreReviews] = useState(false);
  const [userReview, setUserReview] = useState<AppReview | null>(null);
  const [receipt, setReceipt] = useState<DownloadReceipt | null>(null);

  const [downloading, setDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  // Single review form state
  const [ratingInput, setRatingInput] = useState(5);
  const [commentInput, setCommentInput] = useState('');
  const [submittingReview, setSubmittingReview] = useState(false);
  const [reviewError, setReviewError] = useState<string | null>(null);
  const [reviewSuccess, setReviewSuccess] = useState<string | null>(null);

  // Report modal state
  const [reportingReview, setReportingReview] = useState<AppReview | null>(null);
  const [reportReason, setReportReason] = useState<ReportReason>('Saxta rəy');
  const [reportDetails, setReportDetails] = useState('');
  const [submittingReport, setSubmittingReport] = useState(false);
  const [reportFeedback, setReportFeedback] = useState<string | null>(null);

  const loadFirstReviewsPage = useCallback(async () => {
    setLoadingReviews(true);
    try {
      const page = await fetchReviewsPage(appId, REVIEWS_PAGE_SIZE);
      setReviews(page.reviews);
      setReviewsCursor(page.lastDoc);
      setHasMoreReviews(page.hasMore);
    } catch {
      setReviews([]);
      setHasMoreReviews(false);
    } finally {
      setLoadingReviews(false);
    }
  }, [appId]);

  const handleLoadMoreReviews = async () => {
    if (!reviewsCursor || loadingMoreReviews) return;
    setLoadingMoreReviews(true);
    try {
      const page = await fetchReviewsPage(appId, REVIEWS_PAGE_SIZE, reviewsCursor);
      setReviews((prev) => {
        const seen = new Set(prev.map((r) => r.userId));
        const appended = page.reviews.filter((r) => !seen.has(r.userId));
        return [...prev, ...appended];
      });
      setReviewsCursor(page.lastDoc);
      setHasMoreReviews(page.hasMore);
    } finally {
      setLoadingMoreReviews(false);
    }
  };

  useEffect(() => {
    setLoadingApp(true);
    setDownloadStatus(null);
    const unsubApp = subscribeApp(appId, (nextApp) => {
      setApp(nextApp);
      setLoadingApp(false);
    });
    void loadFirstReviewsPage();
    return () => {
      unsubApp();
    };
  }, [appId, loadFirstReviewsPage]);

  useEffect(() => {
    const unsubReceipt = subscribeUserDownloadReceipt(appId, user?.uid, setReceipt);
    const unsubOwnReview = subscribeUserOwnReview(appId, user?.uid, setUserReview);
    return () => {
      unsubReceipt();
      unsubOwnReview();
    };
  }, [appId, user?.uid]);

  const displayedReviews = useMemo(() => {
    if (!userReview) return reviews;
    const withoutOwn = reviews.filter((r) => r.userId !== userReview.userId);
    return [userReview, ...withoutOwn];
  }, [reviews, userReview]);

  useEffect(() => {
    if (userReview) {
      setRatingInput(userReview.rating);
      setCommentInput(userReview.comment);
    } else {
      setRatingInput(5);
      setCommentInput('');
    }
  }, [userReview]);

  const ratingBreakdown = useMemo(() => {
    const counts: Record<number, number> = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    for (const rev of displayedReviews) {
      if (counts[rev.rating] !== undefined) counts[rev.rating] += 1;
    }
    return counts;
  }, [displayedReviews]);

  const handleDownload = async () => {
    if (!app) return;
    setDownloading(true);
    setDownloadStatus(null);
    try {
      const res = await recordDownloadAndTrigger(app, user);
      setDownloadStatus({
        type: 'success',
        text: user
          ? `${res.fileName} (v${res.version}) yüklənməyə başladı və hesabınızda təsdiqləndi. İndi rəy yaza bilərsiniz.`
          : `${res.fileName} (v${res.version}) yüklənməyə başladı.`,
      });
    } catch (err) {
      setDownloadStatus({
        type: 'error',
        text:
          err instanceof Error
            ? err.message
            : 'APK faylı yüklənərkən xəta baş verdi və ya fayl mövcud deyil.',
      });
    } finally {
      setDownloading(false);
    }
  };

  const handleReviewSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!app || !user) return;
    setReviewError(null);
    setReviewSuccess(null);
    setSubmittingReview(true);
    try {
      const displayName = profile?.displayName || user.displayName || 'İstifadəçi';
      await submitOrUpdateReview(app, user, displayName, ratingInput, commentInput, userReview);
      setReviewSuccess(
        userReview ? 'Rəyiniz uğurla yeniləndi.' : 'Rəyiniz və ulduz qiymətiniz dərc olundu.',
      );
      await loadFirstReviewsPage();
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Rəy göndərilə bilmədi.');
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleDeleteOwnReview = async () => {
    if (!app || !userReview) return;
    setReviewError(null);
    setReviewSuccess(null);
    setSubmittingReview(true);
    try {
      await deleteOwnReview(app, userReview);
      setCommentInput('');
      setRatingInput(5);
      setReviewSuccess('Rəyiniz silindi.');
      setReviews((prev) => prev.filter((r) => r.userId !== userReview.userId));
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Rəy silinmədi.');
    } finally {
      setSubmittingReview(false);
    }
  };

  const handleAdminDeleteReview = async (review: AppReview) => {
    if (!app || !isAdmin) return;
    try {
      await adminDeleteReview(app, review.userId);
      setReviews((prev) => prev.filter((r) => r.userId !== review.userId));
    } catch (err) {
      setReviewError(err instanceof Error ? err.message : 'Rəy silinmədi.');
    }
  };

  const handleReportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!app || !reportingReview || !user) return;
    setSubmittingReport(true);
    setReportFeedback(null);
    try {
      const reporterName = profile?.displayName || user.displayName || 'İstifadəçi';
      await submitReport(app, reportingReview, user, reporterName, reportReason, reportDetails);
      setReportingReview(null);
      setReportDetails('');
      setReportFeedback('Şikayətiniz yoxlanılması üçün administratora göndərildi.');
    } catch (err) {
      setReportFeedback(
        err instanceof Error
          ? err.message
          : 'Bu rəy haqqında artıq şikayət göndərmisiniz və ya xəta baş verdi.',
      );
      setReportingReview(null);
    } finally {
      setSubmittingReport(false);
    }
  };

  if (loadingApp) {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="h-8 w-40 bg-slate-200 rounded animate-pulse mb-8" />
        <div className="bg-white border border-slate-200 rounded-2xl p-8 animate-pulse space-y-6">
          <div className="flex gap-6">
            <div className="w-24 h-24 rounded-2xl bg-slate-200" />
            <div className="flex-1 space-y-3">
              <div className="h-7 bg-slate-200 rounded w-1/3" />
              <div className="h-4 bg-slate-100 rounded w-1/2" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!app) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-16 text-center">
        <h1 className="font-display text-2xl font-bold text-slate-900 mb-2">
          Tətbiq tapılmadı
        </h1>
        <p className="text-sm text-slate-600 mb-6">
          Axtardığınız APK silinib və ya mövcud deyil.
        </p>
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-slate-900 rounded-lg"
        >
          <ArrowLeft className="w-4 h-4" />
          Mağazaya qayıt
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-20 space-y-10">
      {/* Breadcrumb Back */}
      <div className="flex items-center gap-3 text-sm text-slate-500">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1.5 font-medium text-slate-700 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Kataloq
        </button>
        <span aria-hidden="true">/</span>
        <span>{app.category}</span>
        <span aria-hidden="true">/</span>
        <span className="text-slate-900 font-medium truncate">{app.name}</span>
      </div>

      {/* Main App Identity & Contiguous Download Module */}
      <section className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="flex items-start gap-5 sm:gap-6">
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl overflow-hidden border border-slate-200 bg-slate-100 shrink-0">
              <SafeImage
                src={app.iconUrl}
                alt={`${app.name} loqosu`}
                fallbackLabel={app.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="min-w-0">
              <h1 className="font-display text-2xl sm:text-3xl font-bold text-slate-900 tracking-tight">
                {app.name}
              </h1>
              <p className="text-xs font-mono text-slate-500 mt-1 break-all">{app.packageName}</p>
              <p className="text-sm text-slate-600 mt-2 max-w-xl">{app.shortDescription}</p>

              {/* Clean unboxed specs row */}
              <div className="mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-600 tabular-nums">
                <StarRatingDisplay
                  rating={app.avgRating}
                  size="md"
                  reviewCount={app.reviewCount}
                />
                <span aria-hidden="true" className="text-slate-300">
                  ·
                </span>
                <span>
                  Kateqoriya: <strong className="text-slate-900">{app.category}</strong>
                </span>
                <span aria-hidden="true" className="text-slate-300">
                  ·
                </span>
                <span>
                  Versiya: <strong className="font-mono text-slate-900">v{app.version}</strong>
                </span>
                <span aria-hidden="true" className="text-slate-300">
                  ·
                </span>
                <span>
                  Ölçü: <strong className="text-slate-900">{app.fileSizeLabel}</strong>
                </span>
                <span aria-hidden="true" className="text-slate-300">
                  ·
                </span>
                <span>
                  Yükləmə:{' '}
                  <strong className="text-slate-900">
                    {app.downloadCount.toLocaleString('az-AZ')}
                  </strong>
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row lg:flex-col items-stretch sm:items-center lg:items-end gap-3 shrink-0">
            <button
              type="button"
              disabled={downloading}
              onClick={() => void handleDownload()}
              className="inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-sm font-semibold text-white bg-blue-700 hover:bg-blue-800 rounded-xl transition-colors whitespace-nowrap disabled:opacity-60"
            >
              <Download className="w-4 h-4" />
              {downloading ? 'APK hazırlanır...' : `APK Yüklə (${app.fileSizeLabel})`}
            </button>
            <p className="text-xs text-slate-500 inline-flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              Administrator tərəfindən təsdiqlənmiş paket
            </p>
          </div>
        </div>

        {downloadStatus ? (
          <div
            className={`mt-6 px-4 py-3 rounded-xl text-sm flex items-center justify-between gap-3 border ${
              downloadStatus.type === 'error'
                ? 'bg-red-50 border-red-200 text-red-800'
                : 'bg-emerald-50 border-emerald-200 text-emerald-800'
            }`}
          >
            <div className="flex items-center gap-2">
              {downloadStatus.type === 'error' ? (
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              )}
              <span>{downloadStatus.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setDownloadStatus(null)}
              className="text-xs font-medium underline shrink-0"
            >
              Bağla
            </button>
          </div>
        ) : null}
      </section>

      {/* Screenshots Gallery */}
      {app.screenshotUrls && app.screenshotUrls.length > 0 ? (
        <section className="space-y-4">
          <h2 className="font-display text-xl font-semibold text-slate-900">Ekran görüntüləri</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {app.screenshotUrls.map((shot, idx) => (
              <button
                key={`${shot}-${idx}`}
                type="button"
                onClick={() => setLightboxImage(shot)}
                className="group aspect-video rounded-xl overflow-hidden border border-slate-200 bg-slate-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              >
                <SafeImage
                  src={shot}
                  alt={`${app.name} ekran görüntüsü ${idx + 1}`}
                  className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-[1.02]"
                />
              </button>
            ))}
          </div>
        </section>
      ) : null}

      {/* Full Description */}
      <section className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-3">
        <h2 className="font-display text-xl font-semibold text-slate-900">Tətbiq haqqında</h2>
        <p className="text-sm sm:text-base text-slate-700 leading-relaxed whitespace-pre-line">
          {app.description}
        </p>
      </section>

      {/* Ratings & Reviews */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Rating Summary & Write/Edit Review */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-5">
            <h2 className="font-display text-xl font-semibold text-slate-900">
              İstifadəçi reytinqi
            </h2>
            <div className="flex items-center gap-6">
              <div>
                <p className="font-display text-4xl font-bold text-slate-900 tabular-nums">
                  {app.avgRating > 0 ? app.avgRating.toFixed(1) : '0.0'}
                </p>
                <div className="mt-1">
                  <StarRatingDisplay rating={app.avgRating} showNumeric={false} />
                </div>
                <p className="text-xs text-slate-500 mt-1 tabular-nums">
                  {app.reviewCount} təsdiqlənmiş rəy
                </p>
              </div>

              <div className="flex-1 space-y-1.5">
                {[5, 4, 3, 2, 1].map((star) => {
                  const count = ratingBreakdown[star] || 0;
                  const pct = app.reviewCount > 0 ? Math.round((count / app.reviewCount) * 100) : 0;
                  return (
                    <div key={star} className="flex items-center gap-2 text-xs">
                      <span className="w-3 text-slate-600 tabular-nums">{star}</span>
                      <Star className="w-3 h-3 fill-amber-500 text-amber-500 shrink-0" />
                      <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500 rounded-full transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <span className="w-7 text-right text-slate-500 tabular-nums">{count}</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Review Gate & Form */}
          <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4">
            <h3 className="font-display text-lg font-semibold text-slate-900">
              {userReview ? 'Mövcud rəyiniz' : 'Qiymətləndir və rəy yaz'}
            </h3>

            {!user ? (
              <div className="space-y-4">
                <p className="text-sm text-slate-600">
                  Saxta rəylərin qarşısını almaq üçün yalnız daxil olmuş və tətbiqi yükləmiş
                  istifadəçilər rəy yaza bilər.
                </p>
                <button
                  type="button"
                  onClick={() => void signInWithGoogle()}
                  className="w-full py-2.5 px-4 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors"
                >
                  Google hesabı ilə daxil ol
                </button>
              </div>
            ) : !receipt ? (
              <div className="space-y-4">
                <div className="flex items-start gap-2.5 text-sm text-slate-700 bg-slate-50 border border-slate-200 rounded-xl p-4">
                  <Lock className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                  <p>
                    Saxta rəylərin qarşısını almaq üçün bu tətbiqə rəy yazmazdan əvvəl APK faylını
                    yükləməlisiniz. Hər istifadəçi yalnız 1 aktiv rəy yaza bilər.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={downloading}
                  onClick={() => void handleDownload()}
                  className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors disabled:opacity-60"
                >
                  <Download className="w-4 h-4" />
                  {downloading ? 'Yüklənir...' : 'APK Yüklə və Rəy Yazmağı Aç'}
                </button>
              </div>
            ) : (
              <form onSubmit={(e) => void handleReviewSubmit(e)} className="space-y-4">
                <div className="text-xs text-emerald-700 inline-flex items-center gap-1.5 font-medium">
                  <CheckCircle2 className="w-4 h-4" />
                  Yükləmə təsdiqlənib · Tətbiq başına 1 aktiv rəy limiti
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1.5">
                    Ulduz qiyməti (1–5)
                  </label>
                  <StarRatingInput
                    value={ratingInput}
                    onChange={setRatingInput}
                    disabled={submittingReview}
                  />
                </div>

                <div>
                  <label
                    htmlFor="review-comment"
                    className="block text-xs font-medium text-slate-700 mb-1.5"
                  >
                    Şərhiniz ({commentInput.length}/{BLUEPRINT_LIMITS.comment.max})
                  </label>
                  <textarea
                    id="review-comment"
                    rows={4}
                    value={commentInput}
                    onChange={(e) => setCommentInput(e.target.value)}
                    minLength={BLUEPRINT_LIMITS.comment.min}
                    maxLength={BLUEPRINT_LIMITS.comment.max}
                    required
                    placeholder="Tətbiqin performansı, dizaynı və sabitliyi barədə təcrübənizi paylaşın..."
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600 resize-y"
                  />
                </div>

                {reviewError ? (
                  <p className="text-xs text-red-600 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    {reviewError}
                  </p>
                ) : null}

                {reviewSuccess ? (
                  <p className="text-xs text-emerald-700 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    {reviewSuccess}
                  </p>
                ) : null}

                <div className="flex items-center gap-2.5">
                  <button
                    type="submit"
                    disabled={submittingReview}
                    className="flex-1 py-2.5 px-4 text-sm font-medium text-white bg-blue-700 hover:bg-blue-800 rounded-lg transition-colors disabled:opacity-60"
                  >
                    {submittingReview
                      ? 'Göndərilir...'
                      : userReview
                        ? 'Rəyi yenilə'
                        : 'Rəyi dərc et'}
                  </button>
                  {userReview ? (
                    <button
                      type="button"
                      disabled={submittingReview}
                      onClick={() => void handleDeleteOwnReview()}
                      className="px-3.5 py-2.5 text-sm font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                    >
                      Sil
                    </button>
                  ) : null}
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Reviews Feed */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-display text-xl font-semibold text-slate-900">
              İstifadəçi rəyləri ({app.reviewCount})
            </h3>
          </div>

          {reportFeedback ? (
            <div className="px-4 py-3 bg-slate-100 border border-slate-200 rounded-xl text-xs text-slate-800 flex items-center justify-between">
              <span>{reportFeedback}</span>
              <button
                type="button"
                onClick={() => setReportFeedback(null)}
                className="font-medium underline"
              >
                Bağla
              </button>
            </div>
          ) : null}

          {loadingReviews ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 space-y-4 animate-pulse">
              <div className="h-4 bg-slate-200 rounded w-1/3" />
              <div className="h-12 bg-slate-100 rounded" />
            </div>
          ) : displayedReviews.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center">
              <p className="text-sm text-slate-600">
                Bu tətbiq üçün hələ rəy yazılmayıb. APK-nı yükləyib ilk rəyi siz yaza bilərsiniz.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-2xl divide-y divide-slate-100">
                {displayedReviews.map((rev) => {
                  const isOwn = user?.uid === rev.userId;
                  const dateLabel = rev.updatedAt?.toDate
                    ? rev.updatedAt.toDate().toLocaleDateString('az-AZ')
                    : '';

                  return (
                    <article key={rev.userId} className="p-6 space-y-2.5">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-semibold text-slate-900">
                              {rev.userName}
                            </span>
                            <span aria-hidden="true" className="text-slate-300">
                              ·
                            </span>
                            <span className="text-xs text-emerald-700 font-medium">
                              Təsdiqlənmiş yükləmə
                            </span>
                            {dateLabel ? (
                              <>
                                <span aria-hidden="true" className="text-slate-300">
                                  ·
                                </span>
                                <span className="text-xs text-slate-400 tabular-nums">
                                  {dateLabel}
                                </span>
                              </>
                            ) : null}
                          </div>
                          <div className="mt-1.5">
                            <StarRatingDisplay rating={rev.rating} showNumeric={false} />
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          {user && !isOwn ? (
                            <button
                              type="button"
                              onClick={() => {
                                setReportingReview(rev);
                                setReportFeedback(null);
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-slate-500 hover:text-amber-700 hover:bg-amber-50 rounded-lg transition-colors"
                            >
                              <Flag className="w-3.5 h-3.5" />
                              Şikayət et
                            </button>
                          ) : null}
                          {isAdmin ? (
                            <button
                              type="button"
                              onClick={() => void handleAdminDeleteReview(rev)}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              Sil
                            </button>
                          ) : null}
                        </div>
                      </div>

                      <p className="text-sm text-slate-700 leading-relaxed">{rev.comment}</p>
                    </article>
                  );
                })}
              </div>

              {hasMoreReviews ? (
                <div className="flex justify-center">
                  <button
                    type="button"
                    disabled={loadingMoreReviews}
                    onClick={() => void handleLoadMoreReviews()}
                    className="px-5 py-2.5 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-xl transition-colors disabled:opacity-60"
                  >
                    {loadingMoreReviews ? 'Rəylər yüklənir...' : 'Daha çox rəy göstər'}
                  </button>
                </div>
              ) : null}
            </div>
          )}
        </div>
      </section>

      {/* Lightbox Modal for Screenshots */}
      {lightboxImage ? (
        <div
          className="fixed inset-0 z-50 bg-slate-950/80 flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-white rounded-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setLightboxImage(null)}
              aria-label="Bağla"
              className="absolute top-3 right-3 p-2 bg-slate-900/75 text-white rounded-lg hover:bg-slate-900"
            >
              <X className="w-5 h-5" />
            </button>
            <SafeImage
              src={lightboxImage}
              alt="Ekran görüntüsü"
              className="w-full max-h-[80vh] object-contain bg-slate-950"
            />
          </div>
        </div>
      ) : null}

      {/* Report Modal */}
      {reportingReview ? (
        <div className="fixed inset-0 z-50 bg-slate-950/60 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 rounded-2xl max-w-md w-full p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h3 className="font-display text-lg font-semibold text-slate-900">
                Rəy barədə şikayət
              </h3>
              <button
                type="button"
                onClick={() => setReportingReview(null)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-700">
              <p className="font-semibold text-slate-900 mb-1">{reportingReview.userName}</p>
              <p className="line-clamp-3">{reportingReview.comment}</p>
            </div>

            <form onSubmit={(e) => void handleReportSubmit(e)} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Şikayət səbəbi
                </label>
                <select
                  value={reportReason}
                  onChange={(e) => setReportReason(e.target.value as ReportReason)}
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                >
                  {REPORT_REASONS.map((reason) => (
                    <option key={reason} value={reason}>
                      {reason}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1.5">
                  Əlavə izah (ixtiyari)
                </label>
                <textarea
                  rows={3}
                  value={reportDetails}
                  onChange={(e) => setReportDetails(e.target.value)}
                  maxLength={BLUEPRINT_LIMITS.detailsMax}
                  placeholder="Şübhəli və ya qayda pozuntusu olan məqamı qeyd edin..."
                  className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setReportingReview(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-100 rounded-lg"
                >
                  Ləğv et
                </button>
                <button
                  type="submit"
                  disabled={submittingReport}
                  className="px-4 py-2 text-sm font-medium text-white bg-amber-600 hover:bg-amber-700 rounded-lg disabled:opacity-60"
                >
                  {submittingReport ? 'Göndərilir...' : 'Şikayəti göndər'}
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : null}
    </div>
  );
}
