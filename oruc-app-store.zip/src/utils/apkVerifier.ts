export interface ApkVerificationResult {
  valid: boolean;
  error?: string;
  entriesCount?: number;
  hasManifest?: boolean;
  hasDex?: boolean;
}

const MAX_APK_BYTES = 200 * 1024 * 1024; // 200 MB
const ZIP_LOCAL_HEADER = 0x04034b50; // PK\x03\x04
const ZIP_EOCD_SIG = 0x06054b50; // PK\x05\x06
const ZIP_CD_SIG = 0x02014b50; // PK\x01\x02

/**
 * Verifies a File in the browser by checking extension, size limits,
 * ZIP local file header magic bytes, and scanning the ZIP Central Directory
 * for AndroidManifest.xml without loading the full APK into memory.
 */
export async function verifyAndroidApkFile(file: File): Promise<ApkVerificationResult> {
  if (!file.name.toLowerCase().endsWith('.apk')) {
    return { valid: false, error: 'Yalnız .apk formatında Android paket faylları qəbul edilir.' };
  }

  if (file.size <= 0) {
    return { valid: false, error: 'Seçilmiş APK faylı boşdur.' };
  }

  if (file.size > MAX_APK_BYTES) {
    return { valid: false, error: 'APK faylının ölçüsü maksimum 200 MB ola bilər.' };
  }

  if (file.size < 22) {
    return { valid: false, error: 'Fayl ölçüsü etibarlı Android APK strukturu üçün çox kiçikdir.' };
  }

  // 1. Check ZIP magic header at offset 0
  const headBuf = await file.slice(0, 4).arrayBuffer();
  const headView = new DataView(headBuf);
  if (headView.getUint32(0, true) !== ZIP_LOCAL_HEADER) {
    return {
      valid: false,
      error: 'Bu fayl etibarlı Android APK (ZIP arxivi) formatında deyil. Saxta və ya zədələnmiş fayl ola bilər.',
    };
  }

  // 2. Locate End of Central Directory (EOCD) in the trailing 66 KB
  const tailSize = Math.min(file.size, 65557);
  const tailOffset = file.size - tailSize;
  const tailBuf = await file.slice(tailOffset, file.size).arrayBuffer();
  const tailBytes = new Uint8Array(tailBuf);
  const tailView = new DataView(tailBuf);

  let eocdPos = -1;
  for (let i = tailBytes.length - 22; i >= 0; i--) {
    if (tailView.getUint32(i, true) === ZIP_EOCD_SIG) {
      const commentLen = tailView.getUint16(i + 20, true);
      if (i + 22 + commentLen === tailBytes.length) {
        eocdPos = i;
        break;
      }
    }
  }

  if (eocdPos === -1) {
    return { valid: false, error: 'APK faylının ZIP mərkəzi kataloqu tapılmadı (fayl zədəlidir).' };
  }

  const cdSize = tailView.getUint32(eocdPos + 12, true);
  const cdOffset = tailView.getUint32(eocdPos + 16, true);

  if (cdOffset + cdSize > file.size || cdSize === 0 || cdSize > 32 * 1024 * 1024) {
    return { valid: false, error: 'APK faylının arxiv strukturu etibarsızdır.' };
  }

  // 3. Scan Central Directory entries for AndroidManifest.xml and classes.dex
  const cdBuf = await file.slice(cdOffset, cdOffset + cdSize).arrayBuffer();
  const cdBytes = new Uint8Array(cdBuf);
  const cdView = new DataView(cdBuf);
  const decoder = new TextDecoder('utf-8');

  let pos = 0;
  let entriesCount = 0;
  let hasManifest = false;
  let hasDex = false;

  while (pos + 46 <= cdBytes.length) {
    if (cdView.getUint32(pos, true) !== ZIP_CD_SIG) {
      break;
    }
    const nameLen = cdView.getUint16(pos + 28, true);
    const extraLen = cdView.getUint16(pos + 30, true);
    const commentLen = cdView.getUint16(pos + 32, true);

    if (pos + 46 + nameLen > cdBytes.length) break;

    const entryName = decoder.decode(cdBytes.subarray(pos + 46, pos + 46 + nameLen));
    entriesCount += 1;

    if (entryName === 'AndroidManifest.xml') {
      hasManifest = true;
    }
    if (/^classes\d*\.dex$/.test(entryName)) {
      hasDex = true;
    }

    pos += 46 + nameLen + extraLen + commentLen;
  }

  if (!hasManifest) {
    return {
      valid: false,
      hasManifest: false,
      entriesCount,
      error:
        'Bu faylın daxilində AndroidManifest.xml tapılmadı. Yalnız həqiqi Android APK paketləri yüklənə bilər.',
    };
  }

  return {
    valid: true,
    entriesCount,
    hasManifest,
    hasDex,
  };
}

export function validateImageFile(file: File): string | null {
  const allowedTypes = ['image/png', 'image/jpeg', 'image/webp'];
  const ext = file.name.toLowerCase().split('.').pop() || '';
  if (!allowedTypes.includes(file.type) && !['png', 'jpg', 'jpeg', 'webp'].includes(ext)) {
    return 'Yalnız PNG, JPG və ya WEBP formatında şəkillər yüklənə bilər.';
  }
  if (file.size <= 0) {
    return 'Seçilmiş şəkil faylı boşdur.';
  }
  if (file.size > 10 * 1024 * 1024) {
    return 'Şəkil ölçüsü maksimum 10 MB ola bilər.';
  }
  return null;
}

export function formatBytesLabel(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}
