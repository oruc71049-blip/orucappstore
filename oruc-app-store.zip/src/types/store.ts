import type { Timestamp } from 'firebase/firestore';
import { STUDIO_ASSETS } from '../lib/studioAssets';

export { STUDIO_ASSETS };

export const ADMIN_EMAIL = 'oruc71049@gmail.com';

export const APP_CATEGORIES = [
  'Məhsuldarlıq',
  'Alətlər',
  'Media',
  'Sağlamlıq',
  'Təhsil',
  'Oyunlar',
  'Maliyyə',
  'Digər',
] as const;

export type AppCategory = (typeof APP_CATEGORIES)[number];

export const REPORT_REASONS = [
  'Saxta rəy',
  'Spam və ya reklam',
  'Təhqiramiz məzmun',
  'Yanlış məlumat',
] as const;

export type ReportReason = (typeof REPORT_REASONS)[number];

export type ReportStatus = 'pending' | 'resolved_deleted' | 'dismissed';

// Validation constants synchronized verbatim with firebase-blueprint.json & firestore.rules
export const BLUEPRINT_LIMITS = {
  idPattern: /^[a-zA-Z0-9_-]+$/,
  packageNamePattern: /^[a-zA-Z0-9_.-]+$/,
  versionPattern: /^[a-zA-Z0-9.+_-]+$/,
  appName: { min: 2, max: 80 },
  packageName: { min: 3, max: 120 },
  shortDescription: { min: 4, max: 160 },
  description: { min: 10, max: 3000 },
  version: { min: 1, max: 32 },
  urlMax: 1000,
  photoUrlMax: 500,
  storagePathMax: 300,
  maxScreenshots: 6,
  comment: { min: 5, max: 1000 },
  displayName: { min: 1, max: 80 },
  detailsMax: 500,
} as const;

export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface AppListing {
  id: string;
  name: string;
  packageName: string;
  shortDescription: string;
  description: string;
  category: AppCategory;
  version: string;
  fileSizeBytes: number;
  fileSizeLabel: string;
  iconUrl: string;
  iconStoragePath?: string;
  screenshotUrls: string[];
  screenshotStoragePaths?: string[];
  apkFileName: string;
  apkDownloadUrl: string;
  apkStoragePath?: string;
  storageProvider?: 'firebase-storage' | 'server-storage';
  downloadCount: number;
  ratingSum: number;
  reviewCount: number;
  avgRating: number;
  createdBy: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface DownloadReceipt {
  appId: string;
  userId: string;
  version: string;
  downloadedAt: Timestamp;
  lastDownloadedAt: Timestamp;
}

export interface AppReview {
  appId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  verifiedDownload: boolean;
  status: 'active' | 'flagged';
  reportCount: number;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface ReviewReport {
  id: string;
  appId: string;
  appName: string;
  reviewUserId: string;
  reviewUserName: string;
  reviewComment: string;
  reporterId: string;
  reporterName: string;
  reason: ReportReason;
  details: string;
  status: ReportStatus;
  adminNote: string;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}

export interface AppFormInput {
  name: string;
  packageName: string;
  shortDescription: string;
  description: string;
  category: AppCategory;
  version: string;
  fileSizeBytes: number;
  fileSizeLabel: string;
  iconUrl: string;
  iconStoragePath?: string;
  screenshotUrls: string[];
  screenshotStoragePaths?: string[];
  apkFileName: string;
  apkDownloadUrl: string;
  apkStoragePath?: string;
  storageProvider?: 'firebase-storage' | 'server-storage';
}
