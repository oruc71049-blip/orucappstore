import type { User } from 'firebase/auth';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  startAfter,
  updateDoc,
  where,
  writeBatch,
  type QueryDocumentSnapshot,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  APP_CATEGORIES,
  BLUEPRINT_LIMITS,
  type AppFormInput,
  type AppListing,
  type AppReview,
  type DownloadReceipt,
  type ReportReason,
  type ReviewReport,
} from '../types/store';
import { deleteAssetByReference } from './storageService';

export class ApkUnavailableError extends Error {
  readonly code = 'APK_UNAVAILABLE';
  constructor(message: string) {
    super(message);
    this.name = 'ApkUnavailableError';
  }
}

export interface ReviewPageResult {
  reviews: AppReview[];
  lastDoc: QueryDocumentSnapshot | null;
  hasMore: boolean;
}

export interface DownloadExecutionResult {
  fileName: string;
  version: string;
  isRepeatDownload: boolean;
}

export function validateAppFormInput(input: AppFormInput): string | null {
  const name = input.name.trim();
  const pkg = input.packageName.trim();
  const shortDesc = input.shortDescription.trim();
  const desc = input.description.trim();
  const version = input.version.trim();

  if (name.length < BLUEPRINT_LIMITS.appName.min || name.length > BLUEPRINT_LIMITS.appName.max) {
    return `Tətbiqin adı ${BLUEPRINT_LIMITS.appName.min}–${BLUEPRINT_LIMITS.appName.max} simvol arası olmalıdır.`;
  }
  if (
    pkg.length < BLUEPRINT_LIMITS.packageName.min ||
    pkg.length > BLUEPRINT_LIMITS.packageName.max ||
    !BLUEPRINT_LIMITS.packageNamePattern.test(pkg)
  ) {
    return 'Paket adı düzgün formatda deyil (məs: az.orucstore.app).';
  }
  if (
    shortDesc.length < BLUEPRINT_LIMITS.shortDescription.min ||
    shortDesc.length > BLUEPRINT_LIMITS.shortDescription.max
  ) {
    return `Qısa təsvir ${BLUEPRINT_LIMITS.shortDescription.min}–${BLUEPRINT_LIMITS.shortDescription.max} simvol arası olmalıdır.`;
  }
  if (
    desc.length < BLUEPRINT_LIMITS.description.min ||
    desc.length > BLUEPRINT_LIMITS.description.max
  ) {
    return `Ətraflı təsvir ${BLUEPRINT_LIMITS.description.min}–${BLUEPRINT_LIMITS.description.max} simvol arası olmalıdır.`;
  }
  if (!APP_CATEGORIES.includes(input.category)) {
    return 'Düzgün kateqoriya seçin.';
  }
  if (
    version.length < BLUEPRINT_LIMITS.version.min ||
    version.length > BLUEPRINT_LIMITS.version.max ||
    !BLUEPRINT_LIMITS.versionPattern.test(version)
  ) {
    return 'Versiya düzgün formatda deyil (məs: 1.4.2).';
  }
  if (!input.apkFileName || !input.apkDownloadUrl || input.fileSizeBytes <= 0) {
    return 'Zəhmət olmasa etibarlı .apk faylı yükləyin.';
  }
  if (input.apkDownloadUrl.trim().length > BLUEPRINT_LIMITS.urlMax) {
    return 'APK yükləmə linki icazə verilən uzunluğu aşır.';
  }
  if (!input.iconUrl || input.iconUrl.trim().length > BLUEPRINT_LIMITS.urlMax) {
    return 'Tətbiq loqosu seçin və ya yükləyin.';
  }
  if (input.screenshotUrls.length > BLUEPRINT_LIMITS.maxScreenshots) {
    return `Maksimum ${BLUEPRINT_LIMITS.maxScreenshots} ekran görüntüsü əlavə edilə bilər.`;
  }
  for (const shot of input.screenshotUrls) {
    if (shot.trim().length > BLUEPRINT_LIMITS.urlMax) {
      return 'Ekran görüntüsü linki icazə verilən uzunluğu aşır.';
    }
  }
  return null;
}

export function subscribeApps(
  onData: (apps: AppListing[]) => void,
  onError?: (err: Error) => void,
  maxItems = 100,
): () => void {
  const path = 'apps';
  const q = query(collection(db, path), orderBy('updatedAt', 'desc'), limit(maxItems));
  return onSnapshot(
    q,
    (snapshot) => {
      const list = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }) as AppListing);
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) onError(wrapped);
      }
    },
  );
}

export function subscribeApp(
  appId: string,
  onData: (app: AppListing | null) => void,
  onError?: (err: Error) => void,
): () => void {
  const path = `apps/${appId}`;
  return onSnapshot(
    doc(db, 'apps', appId),
    (snap) => {
      if (!snap.exists()) {
        onData(null);
        return;
      }
      onData({ ...snap.data(), id: snap.id } as AppListing);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        if (onError && wrapped instanceof Error) onError(wrapped);
      }
    },
  );
}

export async function fetchReviewsPage(
  appId: string,
  pageSize = 8,
  cursor?: QueryDocumentSnapshot | null,
): Promise<ReviewPageResult> {
  const path = `apps/${appId}/reviews`;
  try {
    const col = collection(db, 'apps', appId, 'reviews');
    const q = cursor
      ? query(col, orderBy('updatedAt', 'desc'), startAfter(cursor), limit(pageSize + 1))
      : query(col, orderBy('updatedAt', 'desc'), limit(pageSize + 1));
    const snap = await getDocs(q);
    const hasMore = snap.docs.length > pageSize;
    const docs = hasMore ? snap.docs.slice(0, pageSize) : snap.docs;
    return {
      reviews: docs.map((d) => d.data() as AppReview),
      lastDoc: docs.length > 0 ? docs[docs.length - 1] : null,
      hasMore,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export function subscribeUserOwnReview(
  appId: string,
  userId: string | undefined,
  onData: (review: AppReview | null) => void,
): () => void {
  if (!userId) {
    onData(null);
    return () => {};
  }
  const path = `apps/${appId}/reviews/${userId}`;
  return onSnapshot(
    doc(db, 'apps', appId, 'reviews', userId),
    (snap) => {
      onData(snap.exists() ? (snap.data() as AppReview) : null);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    },
  );
}

export function subscribeUserDownloadReceipt(
  appId: string,
  userId: string | undefined,
  onData: (receipt: DownloadReceipt | null) => void,
): () => void {
  if (!userId) {
    onData(null);
    return () => {};
  }
  const path = `apps/${appId}/downloads/${userId}`;
  return onSnapshot(
    doc(db, 'apps', appId, 'downloads', userId),
    (snap) => {
      onData(snap.exists() ? (snap.data() as DownloadReceipt) : null);
    },
    (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    },
  );
}

export function subscribeReports(
  isAdmin: boolean,
  userId: string | undefined,
  onData: (reports: ReviewReport[]) => void,
): () => void {
  if (!userId) {
    onData([]);
    return () => {};
  }
  const path = 'reports';
  const q = isAdmin
    ? query(collection(db, path), orderBy('createdAt', 'desc'), limit(100))
    : query(collection(db, path), where('reporterId', '==', userId), limit(50));

  return onSnapshot(
    q,
    (snapshot) => {
      const items = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }) as ReviewReport);
      items.sort((a, b) => {
        const aTime = a.createdAt?.toMillis?.() ?? 0;
        const bTime = b.createdAt?.toMillis?.() ?? 0;
        return bTime - aTime;
      });
      onData(items);
    },
    (error) => {
      handleFirestoreError(error, OperationType.LIST, path);
    },
  );
}

function buildSafeAppId(name: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 40);
  const suffix = Math.random().toString(36).slice(2, 8);
  return `${slug || 'app'}_${suffix}`;
}

function sanitizeOptionalStoragePath(val?: string): string {
  return (val || '').trim().slice(0, BLUEPRINT_LIMITS.storagePathMax);
}

export async function createAppListing(input: AppFormInput, adminUser: User): Promise<string> {
  const validationError = validateAppFormInput(input);
  if (validationError) {
    throw new Error(validationError);
  }
  const appId = buildSafeAppId(input.name);
  const path = `apps/${appId}`;

  const cleanScreenshots = input.screenshotUrls
    .map((s) => s.trim().slice(0, BLUEPRINT_LIMITS.urlMax))
    .filter(Boolean)
    .slice(0, BLUEPRINT_LIMITS.maxScreenshots);

  const cleanScreenshotPaths = (input.screenshotStoragePaths || [])
    .map((p) => p.trim().slice(0, BLUEPRINT_LIMITS.storagePathMax))
    .slice(0, BLUEPRINT_LIMITS.maxScreenshots);

  const payload: Record<string, unknown> = {
    id: appId,
    name: input.name.trim().slice(0, BLUEPRINT_LIMITS.appName.max),
    packageName: input.packageName.trim().slice(0, BLUEPRINT_LIMITS.packageName.max),
    shortDescription: input.shortDescription.trim().slice(0, BLUEPRINT_LIMITS.shortDescription.max),
    description: input.description.trim().slice(0, BLUEPRINT_LIMITS.description.max),
    category: input.category,
    version: input.version.trim().slice(0, BLUEPRINT_LIMITS.version.max),
    fileSizeBytes: Math.round(input.fileSizeBytes),
    fileSizeLabel: input.fileSizeLabel.trim().slice(0, 24),
    iconUrl: input.iconUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
    screenshotUrls: cleanScreenshots,
    apkFileName: input.apkFileName.trim().slice(0, 200),
    apkDownloadUrl: input.apkDownloadUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
    downloadCount: 0,
    ratingSum: 0,
    reviewCount: 0,
    avgRating: 0,
    createdBy: adminUser.uid,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  if (input.iconStoragePath) {
    payload.iconStoragePath = sanitizeOptionalStoragePath(input.iconStoragePath);
  }
  if (cleanScreenshotPaths.length > 0) {
    payload.screenshotStoragePaths = cleanScreenshotPaths;
  }
  if (input.apkStoragePath) {
    payload.apkStoragePath = sanitizeOptionalStoragePath(input.apkStoragePath);
  }
  if (input.storageProvider) {
    payload.storageProvider = input.storageProvider;
  }

  try {
    await setDoc(doc(db, 'apps', appId), payload);
    return appId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateAppListing(
  existingApp: AppListing,
  input: AppFormInput,
  idToken: string,
): Promise<void> {
  const validationError = validateAppFormInput(input);
  if (validationError) {
    throw new Error(validationError);
  }
  const path = `apps/${existingApp.id}`;
  const cleanScreenshots = input.screenshotUrls
    .map((s) => s.trim().slice(0, BLUEPRINT_LIMITS.urlMax))
    .filter(Boolean)
    .slice(0, BLUEPRINT_LIMITS.maxScreenshots);

  const cleanScreenshotPaths = (input.screenshotStoragePaths || [])
    .map((p) => p.trim().slice(0, BLUEPRINT_LIMITS.storagePathMax))
    .slice(0, BLUEPRINT_LIMITS.maxScreenshots);

  const updatePayload: Record<string, unknown> = {
    name: input.name.trim().slice(0, BLUEPRINT_LIMITS.appName.max),
    packageName: input.packageName.trim().slice(0, BLUEPRINT_LIMITS.packageName.max),
    shortDescription: input.shortDescription.trim().slice(0, BLUEPRINT_LIMITS.shortDescription.max),
    description: input.description.trim().slice(0, BLUEPRINT_LIMITS.description.max),
    category: input.category,
    version: input.version.trim().slice(0, BLUEPRINT_LIMITS.version.max),
    fileSizeBytes: Math.round(input.fileSizeBytes),
    fileSizeLabel: input.fileSizeLabel.trim().slice(0, 24),
    iconUrl: input.iconUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
    screenshotUrls: cleanScreenshots,
    apkFileName: input.apkFileName.trim().slice(0, 200),
    apkDownloadUrl: input.apkDownloadUrl.trim().slice(0, BLUEPRINT_LIMITS.urlMax),
    updatedAt: serverTimestamp(),
  };

  if (input.iconStoragePath !== undefined) {
    updatePayload.iconStoragePath = sanitizeOptionalStoragePath(input.iconStoragePath);
  }
  if (input.screenshotStoragePaths !== undefined) {
    updatePayload.screenshotStoragePaths = cleanScreenshotPaths;
  }
  if (input.apkStoragePath !== undefined) {
    updatePayload.apkStoragePath = sanitizeOptionalStoragePath(input.apkStoragePath);
  }
  if (input.storageProvider) {
    updatePayload.storageProvider = input.storageProvider;
  }

  try {
    await updateDoc(doc(db, 'apps', existingApp.id), updatePayload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }

  // Only delete old replaced assets AFTER Firestore metadata update succeeds
  const cleanupTasks: Promise<void>[] = [];
  if (existingApp.apkDownloadUrl && existingApp.apkDownloadUrl !== input.apkDownloadUrl) {
    cleanupTasks.push(
      deleteAssetByReference(existingApp.apkStoragePath, existingApp.apkDownloadUrl, idToken),
    );
  }
  if (existingApp.iconUrl && existingApp.iconUrl !== input.iconUrl) {
    cleanupTasks.push(
      deleteAssetByReference(existingApp.iconStoragePath, existingApp.iconUrl, idToken),
    );
  }
  const oldShots = existingApp.screenshotUrls || [];
  const oldShotPaths = existingApp.screenshotStoragePaths || [];
  oldShots.forEach((oldUrl, idx) => {
    if (!cleanScreenshots.includes(oldUrl)) {
      cleanupTasks.push(deleteAssetByReference(oldShotPaths[idx], oldUrl, idToken));
    }
  });
  await Promise.allSettled(cleanupTasks);
}

export async function deleteAppListing(app: AppListing, idToken: string): Promise<void> {
  const path = `apps/${app.id}`;
  try {
    const [reviewsSnap, downloadsSnap, reportsSnap] = await Promise.all([
      getDocs(collection(db, 'apps', app.id, 'reviews')),
      getDocs(collection(db, 'apps', app.id, 'downloads')),
      getDocs(query(collection(db, 'reports'), where('appId', '==', app.id))),
    ]);

    const childRefs = [
      ...reviewsSnap.docs.map((d) => d.ref),
      ...downloadsSnap.docs.map((d) => d.ref),
      ...reportsSnap.docs.map((d) => d.ref),
    ];

    // Commit child deletions in chunks of 400 (Firestore batch limit is 500)
    const CHUNK_SIZE = 400;
    for (let i = 0; i < childRefs.length; i += CHUNK_SIZE) {
      const batch = writeBatch(db);
      const chunk = childRefs.slice(i, i + CHUNK_SIZE);
      chunk.forEach((ref) => batch.delete(ref));
      // Include parent app deletion in the final chunk so app stays intact if earlier chunk fails
      if (i + CHUNK_SIZE >= childRefs.length) {
        batch.delete(doc(db, 'apps', app.id));
      }
      await batch.commit();
    }

    if (childRefs.length === 0) {
      const batch = writeBatch(db);
      batch.delete(doc(db, 'apps', app.id));
      await batch.commit();
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }

  // Clean up Storage / server files ONLY after Firestore deletion succeeds
  const assetCleanups: Promise<void>[] = [
    deleteAssetByReference(app.apkStoragePath, app.apkDownloadUrl, idToken),
    deleteAssetByReference(app.iconStoragePath, app.iconUrl, idToken),
  ];
  const shots = app.screenshotUrls || [];
  const shotPaths = app.screenshotStoragePaths || [];
  shots.forEach((url, idx) => {
    assetCleanups.push(deleteAssetByReference(shotPaths[idx], url, idToken));
  });
  await Promise.allSettled(assetCleanups);
}

async function verifyApkDownloadAvailability(apkDownloadUrl: string): Promise<void> {
  if (!apkDownloadUrl) {
    throw new ApkUnavailableError('Bu tətbiq üçün etibarlı APK yükləmə linki mövcud deyil.');
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 8000);
  try {
    if (apkDownloadUrl.startsWith('/api/apks/download/')) {
      const res = await fetch(apkDownloadUrl, { method: 'HEAD', signal: controller.signal });
      if (res.status === 404 || res.status === 400) {
        throw new ApkUnavailableError(
          'APK faylı serverdə tapılmadı və ya silinib. Zəhmət olmasa administratorla əlaqə saxlayın.',
        );
      }
      if (!res.ok) {
        throw new ApkUnavailableError(`APK faylı yükləmə üçün əlçatan deyil (HTTP ${res.status}).`);
      }
      return;
    }

    // For Firebase Storage or HTTPS URLs, check with HEAD / 4-byte Range
    const res = await fetch(apkDownloadUrl, {
      method: 'HEAD',
      signal: controller.signal,
    });
    if (res.status === 404 || res.status === 410) {
      throw new ApkUnavailableError(
        'APK faylı bulud yaddaşından silinib və ya artıq mövcud deyil.',
      );
    }
    if (res.status === 403) {
      throw new ApkUnavailableError('APK faylına giriş icazəsi və ya yükləmə tokeni etibarsızdır.');
    }
  } catch (err) {
    if (err instanceof ApkUnavailableError) {
      throw err;
    }
    if (err instanceof DOMException && err.name === 'AbortError') {
      throw new ApkUnavailableError('APK serverinə qoşulma vaxtı bitdi. Yenidən cəhd edin.');
    }
    // If CORS blocks HEAD on an external URL, do not falsely fail same-day browser download
    if (apkDownloadUrl.startsWith('/')) {
      throw new ApkUnavailableError('APK faylı yoxlanılarkən şəbəkə xətası baş verdi.');
    }
  } finally {
    window.clearTimeout(timer);
  }
}

function buildSafeDownloadFileName(appName: string, version: string): string {
  const cleanName = appName.trim().replace(/[^a-zA-Z0-9._-]+/g, '_').replace(/^_+|_+$/g, '') || 'app';
  const cleanVer = version.trim().replace(/[^a-zA-Z0-9.+_-]+/g, '_') || '1.0.0';
  return `${cleanName}-v${cleanVer}.apk`;
}

export async function recordDownloadAndTrigger(
  app: AppListing,
  user: User | null,
): Promise<DownloadExecutionResult> {
  // 1. Verify the APK file actually exists & is reachable BEFORE recording download or incrementing counter
  await verifyApkDownloadAvailability(app.apkDownloadUrl);

  const fileName = buildSafeDownloadFileName(app.name, app.version);
  let isRepeatDownload = false;

  // 2. Record verified user download receipt atomically (count increments ONLY on first download)
  if (user && user.emailVerified) {
    const receiptPath = `apps/${app.id}/downloads/${user.uid}`;
    const receiptRef = doc(db, 'apps', app.id, 'downloads', user.uid);
    const appRef = doc(db, 'apps', app.id);

    try {
      const [existingReceipt, freshAppSnap] = await Promise.all([
        getDoc(receiptRef),
        getDoc(appRef),
      ]);
      const currentCount = freshAppSnap.exists()
        ? ((freshAppSnap.data().downloadCount as number) ?? app.downloadCount)
        : app.downloadCount;

      if (!existingReceipt.exists()) {
        const batch = writeBatch(db);
        batch.set(receiptRef, {
          appId: app.id,
          userId: user.uid,
          version: app.version,
          downloadedAt: serverTimestamp(),
          lastDownloadedAt: serverTimestamp(),
        });
        batch.update(appRef, {
          downloadCount: currentCount + 1,
        });
        await batch.commit();
      } else {
        isRepeatDownload = true;
        await updateDoc(receiptRef, {
          version: app.version,
          lastDownloadedAt: serverTimestamp(),
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, receiptPath);
    }
  }

  // 3. Trigger actual browser download without corrupting Firebase Storage query tokens
  const downloadUrl = app.apkDownloadUrl.startsWith('/api/apks/download/')
    ? `${app.apkDownloadUrl}?name=${encodeURIComponent(fileName)}`
    : app.apkDownloadUrl;

  const anchor = document.createElement('a');
  anchor.href = downloadUrl;
  anchor.download = fileName;
  anchor.rel = 'noopener noreferrer';
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  return {
    fileName,
    version: app.version,
    isRepeatDownload,
  };
}

export async function submitOrUpdateReview(
  app: AppListing,
  user: User,
  displayName: string,
  rating: number,
  comment: string,
  existingReview: AppReview | null,
): Promise<void> {
  if (!user.emailVerified) {
    throw new Error('Rəy yazmaq üçün e-poçt ünvanınız təsdiqlənməlidir.');
  }
  const cleanRating = Math.round(rating);
  if (cleanRating < 1 || cleanRating > 5) {
    throw new Error('Qiymət 1 ilə 5 ulduz arasında olmalıdır.');
  }
  const trimmedComment = comment.trim().slice(0, BLUEPRINT_LIMITS.comment.max);
  if (trimmedComment.length < BLUEPRINT_LIMITS.comment.min) {
    throw new Error(`Rəy ən azı ${BLUEPRINT_LIMITS.comment.min} simvoldan ibarət olmalıdır.`);
  }
  const cleanName = (displayName || user.displayName || 'İstifadəçi')
    .trim()
    .slice(0, BLUEPRINT_LIMITS.displayName.max);

  const reviewPath = `apps/${app.id}/reviews/${user.uid}`;
  const reviewRef = doc(db, 'apps', app.id, 'reviews', user.uid);
  const appRef = doc(db, 'apps', app.id);

  try {
    const freshAppSnap = await getDoc(appRef);
    const baseSum = freshAppSnap.exists()
      ? ((freshAppSnap.data().ratingSum as number) ?? app.ratingSum)
      : app.ratingSum;
    const baseCount = freshAppSnap.exists()
      ? ((freshAppSnap.data().reviewCount as number) ?? app.reviewCount)
      : app.reviewCount;

    const batch = writeBatch(db);
    if (!existingReview) {
      const nextSum = baseSum + cleanRating;
      const nextCount = baseCount + 1;
      const nextAvg = Number((nextSum / nextCount).toFixed(2));

      batch.set(reviewRef, {
        appId: app.id,
        userId: user.uid,
        userName: cleanName,
        rating: cleanRating,
        comment: trimmedComment,
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      batch.update(appRef, {
        ratingSum: nextSum,
        reviewCount: nextCount,
        avgRating: nextAvg,
      });
    } else {
      const delta = cleanRating - existingReview.rating;
      const nextSum = Math.max(0, baseSum + delta);
      const nextAvg = baseCount > 0 ? Number((nextSum / baseCount).toFixed(2)) : 0;

      batch.update(reviewRef, {
        rating: cleanRating,
        comment: trimmedComment,
        userName: cleanName,
        updatedAt: serverTimestamp(),
      });
      batch.update(appRef, {
        ratingSum: nextSum,
        reviewCount: baseCount,
        avgRating: nextAvg,
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, reviewPath);
  }
}

export async function deleteOwnReview(app: AppListing, review: AppReview): Promise<void> {
  const reviewPath = `apps/${app.id}/reviews/${review.userId}`;
  const reviewRef = doc(db, 'apps', app.id, 'reviews', review.userId);
  const appRef = doc(db, 'apps', app.id);

  try {
    const freshAppSnap = await getDoc(appRef);
    const baseCount = freshAppSnap.exists()
      ? ((freshAppSnap.data().reviewCount as number) ?? app.reviewCount)
      : app.reviewCount;
    const baseSum = freshAppSnap.exists()
      ? ((freshAppSnap.data().ratingSum as number) ?? app.ratingSum)
      : app.ratingSum;

    const nextCount = Math.max(0, baseCount - 1);
    const nextSum = Math.max(0, baseSum - review.rating);
    const nextAvg = nextCount > 0 ? Number((nextSum / nextCount).toFixed(2)) : 0;

    const batch = writeBatch(db);
    batch.delete(reviewRef);
    batch.update(appRef, {
      ratingSum: nextSum,
      reviewCount: nextCount,
      avgRating: nextAvg,
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, reviewPath);
  }
}

export async function submitReport(
  app: AppListing,
  review: AppReview,
  reporter: User,
  reporterName: string,
  reason: ReportReason,
  details: string,
): Promise<void> {
  if (!reporter.emailVerified) {
    throw new Error('Şikayət göndərmək üçün e-poçt ünvanınız təsdiqlənməlidir.');
  }
  const reportId = `${app.id}__${review.userId}__${reporter.uid}`;
  const path = `reports/${reportId}`;
  try {
    await setDoc(doc(db, 'reports', reportId), {
      appId: app.id,
      appName: app.name.slice(0, BLUEPRINT_LIMITS.appName.max),
      reviewUserId: review.userId,
      reviewUserName: review.userName.slice(0, BLUEPRINT_LIMITS.displayName.max),
      reviewComment: review.comment.slice(0, BLUEPRINT_LIMITS.comment.max),
      reporterId: reporter.uid,
      reporterName: (reporterName || reporter.displayName || 'İstifadəçi').slice(
        0,
        BLUEPRINT_LIMITS.displayName.max,
      ),
      reason,
      details: details.trim().slice(0, BLUEPRINT_LIMITS.detailsMax),
      status: 'pending',
      adminNote: '',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function adminDeleteReview(
  app: AppListing,
  reviewUserId: string,
  reportId?: string,
  adminNote = 'Rəy qaydaları pozduğu üçün silindi.',
): Promise<void> {
  const reviewPath = `apps/${app.id}/reviews/${reviewUserId}`;
  try {
    const reviewsSnap = await getDocs(collection(db, 'apps', app.id, 'reviews'));
    let nextSum = 0;
    let nextCount = 0;

    reviewsSnap.forEach((docSnap) => {
      if (docSnap.id !== reviewUserId) {
        const data = docSnap.data() as AppReview;
        nextSum += data.rating;
        nextCount += 1;
      }
    });

    const nextAvg = nextCount > 0 ? Number((nextSum / nextCount).toFixed(2)) : 0;

    const batch = writeBatch(db);
    batch.delete(doc(db, 'apps', app.id, 'reviews', reviewUserId));
    batch.update(doc(db, 'apps', app.id), {
      ratingSum: nextSum,
      reviewCount: nextCount,
      avgRating: nextAvg,
      updatedAt: serverTimestamp(),
    });

    if (reportId) {
      batch.update(doc(db, 'reports', reportId), {
        status: 'resolved_deleted',
        adminNote: adminNote.slice(0, BLUEPRINT_LIMITS.detailsMax),
        updatedAt: serverTimestamp(),
      });
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, reviewPath);
  }
}

export async function adminDismissReport(reportId: string, adminNote: string): Promise<void> {
  const path = `reports/${reportId}`;
  try {
    await updateDoc(doc(db, 'reports', reportId), {
      status: 'dismissed',
      adminNote: (adminNote.trim() || 'Yoxlanıldı, pozuntu aşkar edilmədi.').slice(
        0,
        BLUEPRINT_LIMITS.detailsMax,
      ),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function fetchAllReviewsForAdmin(apps: AppListing[]): Promise<AppReview[]> {
  const results: AppReview[] = [];
  await Promise.all(
    apps.map(async (app) => {
      const path = `apps/${app.id}/reviews`;
      try {
        const snap = await getDocs(
          query(collection(db, 'apps', app.id, 'reviews'), orderBy('updatedAt', 'desc'), limit(50)),
        );
        snap.forEach((d) => results.push(d.data() as AppReview));
      } catch (error) {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    }),
  );
  results.sort((a, b) => (b.updatedAt?.toMillis?.() ?? 0) - (a.updatedAt?.toMillis?.() ?? 0));
  return results;
}
