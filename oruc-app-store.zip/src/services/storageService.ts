import { deleteObject, getDownloadURL, ref, uploadBytesResumable } from 'firebase/storage';
import { storage } from '../lib/firebase';
import {
  formatBytesLabel,
  validateImageFile,
  verifyAndroidApkFile,
} from '../utils/apkVerifier';

export type StorageProviderType = 'firebase-storage' | 'server-storage';

export interface UploadedApkResult {
  apkFileName: string;
  apkDownloadUrl: string;
  apkStoragePath?: string;
  fileSizeBytes: number;
  fileSizeLabel: string;
  storageProvider: StorageProviderType;
  fallbackNotice?: string;
}

export interface UploadedMediaResult {
  url: string;
  storagePath?: string;
  storageProvider: StorageProviderType;
  fallbackNotice?: string;
}

const BUCKET_FALLBACK_NOTICE =
  'Firebase Storage bucket layihədə hələ aktiv edilməyib; fayl müvəqqəti olaraq server yaddaşına yükləndi. Daimi bulud saxlanması üçün Firebase Console-da Storage-ı aktivləşdirin.';

let cachedBucketReachable: boolean | null = null;
let bucketCheckAt = 0;

function sanitizeStorageFileName(originalName: string, forcedExt?: string): string {
  const dotIdx = originalName.lastIndexOf('.');
  const rawExt = dotIdx >= 0 ? originalName.slice(dotIdx).toLowerCase() : '';
  const ext = forcedExt || rawExt || '';
  const base = (dotIdx >= 0 ? originalName.slice(0, dotIdx) : originalName)
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .replace(/_+/g, '_')
    .slice(0, 48);
  const unique = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  return `${unique}_${base || 'file'}${ext}`;
}

async function isFirebaseStorageAvailable(): Promise<boolean> {
  const bucket = storage.app.options.storageBucket;
  if (!bucket) return false;

  // Cache positive/negative probe for 60 seconds
  if (cachedBucketReachable !== null && Date.now() - bucketCheckAt < 60_000) {
    return cachedBucketReachable;
  }

  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 3500);
  try {
    const res = await fetch(
      `https://firebasestorage.googleapis.com/v0/b/${encodeURIComponent(bucket)}/o?maxResults=1`,
      { method: 'GET', signal: controller.signal },
    );
    // 200, 401, or 403 mean the bucket exists; 404 means Storage is not provisioned yet.
    const exists = res.status !== 404;
    cachedBucketReachable = exists;
    bucketCheckAt = Date.now();
    return exists;
  } catch {
    // Network/CORS failure when bucket is absent or unreachable
    cachedBucketReachable = false;
    bucketCheckAt = Date.now();
    return false;
  } finally {
    window.clearTimeout(timer);
  }
}

function isBucketMissingError(error: unknown): boolean {
  if (!error || typeof error !== 'object') return false;
  const code = String((error as { code?: unknown }).code || '');
  const message = String((error as { message?: unknown }).message || '').toLowerCase();
  return (
    code === 'storage/bucket-not-found' ||
    code === 'storage/project-not-found' ||
    code === 'storage/unknown' ||
    code === 'storage/retry-limit-exceeded' ||
    message.includes('404') ||
    message.includes('not found')
  );
}

function uploadToFirebaseStorage(
  storagePath: string,
  file: File,
  contentType: string,
  onProgress?: (pct: number) => void,
): Promise<string> {
  return new Promise((resolve, reject) => {
    const fileRef = ref(storage, storagePath);
    const task = uploadBytesResumable(fileRef, file, { contentType });

    task.on(
      'state_changed',
      (snapshot) => {
        if (snapshot.totalBytes > 0 && onProgress) {
          const pct = Math.min(99, Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100));
          onProgress(pct);
        }
      },
      (err) => {
        reject(err);
      },
      async () => {
        try {
          const downloadUrl = await getDownloadURL(task.snapshot.ref);
          onProgress?.(100);
          resolve(downloadUrl);
        } catch (err) {
          reject(err);
        }
      },
    );
  });
}

function uploadViaXhr<T>(
  endpoint: string,
  fieldName: string,
  file: File,
  idToken: string,
  onProgress?: (pct: number) => void,
): Promise<T> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const formData = new FormData();
    formData.append(fieldName, file);

    xhr.open('POST', endpoint, true);
    xhr.setRequestHeader('Authorization', `Bearer ${idToken}`);

    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable && event.total > 0 && onProgress) {
        const pct = Math.min(99, Math.round((event.loaded / event.total) * 100));
        onProgress(pct);
      }
    };

    xhr.onload = () => {
      let parsed: Record<string, unknown> = {};
      try {
        parsed = JSON.parse(xhr.responseText || '{}') as Record<string, unknown>;
      } catch {
        parsed = {};
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        onProgress?.(100);
        resolve(parsed as T);
      } else {
        const errMsg =
          typeof parsed.error === 'string'
            ? parsed.error
            : `Yükləmə xətası (HTTP ${xhr.status}).`;
        reject(new Error(errMsg));
      }
    };

    xhr.onerror = () => {
      reject(new Error('Şəbəkə xətası səbəbindən fayl yüklənmədi.'));
    };

    xhr.send(formData);
  });
}

export async function uploadApkAsset(
  file: File,
  appIdHint: string,
  idToken: string,
  onProgress?: (pct: number) => void,
): Promise<UploadedApkResult> {
  const check = await verifyAndroidApkFile(file);
  if (!check.valid) {
    throw new Error(check.error || 'Fayl həqiqi Android APK kimi təsdiqlənmədi.');
  }

  const safeFolder = appIdHint.replace(/[^a-zA-Z0-9_-]/g, '_') || 'pending';
  const safeName = sanitizeStorageFileName(file.name, '.apk');
  const storagePath = `apks/${safeFolder}/${safeName}`;

  if (await isFirebaseStorageAvailable()) {
    try {
      const downloadUrl = await uploadToFirebaseStorage(
        storagePath,
        file,
        'application/vnd.android.package-archive',
        onProgress,
      );
      return {
        apkFileName: safeName,
        apkDownloadUrl: downloadUrl,
        apkStoragePath: storagePath,
        fileSizeBytes: file.size,
        fileSizeLabel: formatBytesLabel(file.size),
        storageProvider: 'firebase-storage',
      };
    } catch (err) {
      if (!isBucketMissingError(err)) {
        throw err instanceof Error ? err : new Error('APK Firebase Storage-a yüklənmədi.');
      }
      cachedBucketReachable = false;
      bucketCheckAt = Date.now();
    }
  }

  const serverRes = await uploadViaXhr<{
    apkFileName: string;
    apkDownloadUrl: string;
    fileSizeBytes: number;
    fileSizeLabel: string;
  }>('/api/upload/apk', 'apk', file, idToken, onProgress);

  return {
    apkFileName: serverRes.apkFileName,
    apkDownloadUrl: serverRes.apkDownloadUrl,
    fileSizeBytes: serverRes.fileSizeBytes ?? file.size,
    fileSizeLabel: serverRes.fileSizeLabel ?? formatBytesLabel(file.size),
    storageProvider: 'server-storage',
    fallbackNotice: BUCKET_FALLBACK_NOTICE,
  };
}

export async function uploadMediaAsset(
  file: File,
  folder: 'icons' | 'screenshots',
  appIdHint: string,
  idToken: string,
  onProgress?: (pct: number) => void,
): Promise<UploadedMediaResult> {
  const errMsg = validateImageFile(file);
  if (errMsg) {
    throw new Error(errMsg);
  }

  const safeFolder = appIdHint.replace(/[^a-zA-Z0-9_-]/g, '_') || 'pending';
  const safeName = sanitizeStorageFileName(file.name);
  const storagePath = `${folder}/${safeFolder}/${safeName}`;
  const contentType = file.type || 'image/png';

  if (await isFirebaseStorageAvailable()) {
    try {
      const url = await uploadToFirebaseStorage(storagePath, file, contentType, onProgress);
      return {
        url,
        storagePath,
        storageProvider: 'firebase-storage',
      };
    } catch (err) {
      if (!isBucketMissingError(err)) {
        throw err instanceof Error ? err : new Error('Şəkil Firebase Storage-a yüklənmədi.');
      }
      cachedBucketReachable = false;
      bucketCheckAt = Date.now();
    }
  }

  const serverRes = await uploadViaXhr<{ fileName: string; url: string }>(
    '/api/upload/media',
    'image',
    file,
    idToken,
    onProgress,
  );

  return {
    url: serverRes.url,
    storageProvider: 'server-storage',
    fallbackNotice: BUCKET_FALLBACK_NOTICE,
  };
}

export async function deleteAssetByReference(
  storagePath: string | undefined,
  url: string | undefined,
  idToken: string,
): Promise<void> {
  if (storagePath && /^(apks|icons|screenshots)\//.test(storagePath)) {
    try {
      await deleteObject(ref(storage, storagePath));
    } catch (err) {
      const code = (err as { code?: string })?.code;
      if (code !== 'storage/object-not-found') {
        console.warn('Storage object cleanup warning:', storagePath, err);
      }
    }
    return;
  }

  if (!url) return;

  if (url.startsWith('/api/apks/download/')) {
    const rawName = url.slice('/api/apks/download/'.length).split('?')[0];
    if (rawName) {
      await fetch(`/api/apks/${encodeURIComponent(decodeURIComponent(rawName))}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${idToken}` },
      }).catch(() => undefined);
    }
    return;
  }

  if (url.startsWith('/api/media/')) {
    const rawName = url.slice('/api/media/'.length).split('?')[0];
    if (rawName) {
      await fetch(`/api/media/${encodeURIComponent(decodeURIComponent(rawName))}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${idToken}` },
      }).catch(() => undefined);
    }
  }
}
