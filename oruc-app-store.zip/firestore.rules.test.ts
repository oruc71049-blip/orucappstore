/**
 * Executable Firebase Emulator Security Test Suite for Oruc App Store
 * Covers all 12 Dirty Dozen adversarial checks + positive verified user/admin workflows.
 *
 * Run with:
 *   npx firebase emulators:exec --only firestore "npx tsx firestore.rules.test.ts"
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { after, before, beforeEach, describe, it } from 'node:test';
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
  type RulesTestEnvironment,
} from '@firebase/rules-unit-testing';
import {
  deleteDoc,
  doc,
  getDoc,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';

const PROJECT_ID = 'tensile-codex-v7cdj';
const ADMIN_EMAIL = 'oruc71049@gmail.com';
const ADMIN_UID = 'admin_oruc_uid';
const USER_A_UID = 'user_a_uid';
const USER_B_UID = 'user_b_uid';

function parseEmulatorHost(): { host: string; port: number } {
  const raw = process.env.FIRESTORE_EMULATOR_HOST || '127.0.0.1:8080';
  const [host, portStr] = raw.split(':');
  return { host: host || '127.0.0.1', port: Number(portStr || 8080) };
}

function buildValidAppPayload(id: string, createdBy: string) {
  return {
    id,
    name: 'Atlas Qeydlər',
    packageName: 'az.orucstore.atlasnotes',
    shortDescription: 'Sürətli və etibarlı Android qeyd tətbiqi.',
    description: 'Oruc App Store üzərindən yoxlanılmış Android APK paketi və tam təsvir mətni.',
    category: 'Məhsuldarlıq',
    version: '1.2.0',
    fileSizeBytes: 12_400_000,
    fileSizeLabel: '11.8 MB',
    iconUrl: 'https://firebasestorage.googleapis.com/v0/b/tensile-codex-v7cdj.firebasestorage.app/o/icons%2Fapp.png?alt=media&token=abc',
    iconStoragePath: `icons/${id}/icon.png`,
    screenshotUrls: [
      'https://firebasestorage.googleapis.com/v0/b/tensile-codex-v7cdj.firebasestorage.app/o/screenshots%2Fshot1.png?alt=media&token=abc',
    ],
    screenshotStoragePaths: [`screenshots/${id}/shot1.png`],
    apkFileName: 'atlas_notes_v1.2.0.apk',
    apkDownloadUrl:
      'https://firebasestorage.googleapis.com/v0/b/tensile-codex-v7cdj.firebasestorage.app/o/apks%2Fatlas.apk?alt=media&token=abc',
    apkStoragePath: `apks/${id}/atlas.apk`,
    storageProvider: 'firebase-storage',
    downloadCount: 0,
    ratingSum: 0,
    reviewCount: 0,
    avgRating: 0,
    createdBy,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };
}

let testEnv: RulesTestEnvironment;

before(async () => {
  const rules = fs.readFileSync('firestore.rules', 'utf8');
  const { host, port } = parseEmulatorHost();
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules, host, port },
  });
});

after(async () => {
  await testEnv?.cleanup();
});

beforeEach(async () => {
  await testEnv.clearFirestore();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    const db = ctx.firestore();
    const now = Timestamp.now();

    await setDoc(doc(db, 'apps', 'app_1'), {
      id: 'app_1',
      name: 'Atlas Qeydlər',
      packageName: 'az.orucstore.atlasnotes',
      shortDescription: 'Sürətli və etibarlı Android qeyd tətbiqi.',
      description: 'Oruc App Store üzərindən yoxlanılmış Android APK paketi və tam təsvir mətni.',
      category: 'Məhsuldarlıq',
      version: '1.0.0',
      fileSizeBytes: 8_500_000,
      fileSizeLabel: '8.1 MB',
      iconUrl: '/api/media/icon1.png',
      screenshotUrls: ['/api/media/shot1.png'],
      apkFileName: 'atlas.apk',
      apkDownloadUrl: '/api/apks/download/atlas.apk',
      downloadCount: 0,
      ratingSum: 0,
      reviewCount: 0,
      avgRating: 0,
      createdBy: ADMIN_UID,
      createdAt: now,
      updatedAt: now,
    });

    await setDoc(doc(db, 'users', USER_B_UID), {
      uid: USER_B_UID,
      displayName: 'İstifadəçi B',
      email: 'userb@example.com',
      photoURL: 'https://example.com/b.jpg',
      createdAt: now,
      updatedAt: now,
    });
  });
});

describe('Oruc App Store Firestore Security Rules — Dirty Dozen & Positive Flows', () => {
  it('1. Non-admin APK creation is blocked', async () => {
    const userDb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
    }).firestore();
    await assertFails(setDoc(doc(userDb, 'apps', 'evil_app'), buildValidAppPayload('evil_app', USER_A_UID)));
  });

  it('2. Shadow field injection on App update is blocked even for admin', async () => {
    const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
      email: ADMIN_EMAIL,
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      updateDoc(doc(adminDb, 'apps', 'app_1'), {
        isFeatured: true,
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('3. Arbitrary downloadCount inflation is blocked', async () => {
    const userDb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      updateDoc(doc(userDb, 'apps', 'app_1'), {
        downloadCount: 999999,
      }),
    );
    // Even +1 without atomic receipt creation is blocked
    await assertFails(
      updateDoc(doc(userDb, 'apps', 'app_1'), {
        downloadCount: 1,
      }),
    );
  });

  it('4. Fake review without prior verified APK download is blocked', async () => {
    const userDb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userDb, 'apps', 'app_1', 'reviews', USER_A_UID), {
        appId: 'app_1',
        userId: USER_A_UID,
        userName: 'İstifadəçi A',
        rating: 5,
        comment: 'Yükləmədən yazılmış saxta rəy.',
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('5. Second active review under arbitrary doc ID is blocked', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      const now = Timestamp.now();
      await setDoc(doc(db, 'apps', 'app_1', 'downloads', USER_A_UID), {
        appId: 'app_1',
        userId: USER_A_UID,
        version: '1.0.0',
        downloadedAt: now,
        lastDownloadedAt: now,
      });
    });

    const userDb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userDb, 'apps', 'app_1', 'reviews', 'random_second_doc'), {
        appId: 'app_1',
        userId: USER_A_UID,
        userName: 'İstifadəçi A',
        rating: 5,
        comment: 'İkinci saxta rəy cəhdi.',
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('6. Identity spoofing on review create is blocked', async () => {
    const userDb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userDb, 'apps', 'app_1', 'reviews', USER_B_UID), {
        appId: 'app_1',
        userId: USER_B_UID,
        userName: 'Saxta Ad',
        rating: 1,
        comment: 'Başqa istifadəçi adından rəy.',
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('7. Out-of-bounds star rating (10 or 0) is blocked', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      const now = Timestamp.now();
      await setDoc(doc(db, 'apps', 'app_1', 'downloads', USER_A_UID), {
        appId: 'app_1',
        userId: USER_A_UID,
        version: '1.0.0',
        downloadedAt: now,
        lastDownloadedAt: now,
      });
    });

    const userDb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userDb, 'apps', 'app_1', 'reviews', USER_A_UID), {
        appId: 'app_1',
        userId: USER_A_UID,
        userName: 'İstifadəçi A',
        rating: 10,
        comment: 'Yanlış ulduz qiyməti.',
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('8. Unverified email or non-Google sign-in provider spoofing admin email is blocked', async () => {
    const spoofedDb = testEnv.authenticatedContext('spoof_uid', {
      email: ADMIN_EMAIL,
      email_verified: false,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(setDoc(doc(spoofedDb, 'apps', 'spoof_app'), buildValidAppPayload('spoof_app', 'spoof_uid')));

    const nonGoogleDb = testEnv.authenticatedContext('password_uid', {
      email: ADMIN_EMAIL,
      email_verified: true,
      firebase: { sign_in_provider: 'password' },
    }).firestore();
    await assertFails(setDoc(doc(nonGoogleDb, 'apps', 'spoof_pw_app'), buildValidAppPayload('spoof_pw_app', 'password_uid')));
  });

  it('9. Cross-user PII profile read is blocked', async () => {
    const userADb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(getDoc(doc(userADb, 'users', USER_B_UID)));
  });

  it('10. Self-promotion & stale /admins doc delegation are completely blocked', async () => {
    const userADb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'attacker@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userADb, 'admins', USER_A_UID), {
        uid: USER_A_UID,
        email: 'attacker@example.com',
        addedBy: USER_A_UID,
        createdAt: serverTimestamp(),
      }),
    );

    // Even if a legacy /admins/{uid} document existed in Firestore, it confers ZERO admin privilege
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      await setDoc(doc(db, 'admins', USER_A_UID), {
        uid: USER_A_UID,
        email: 'legacy@example.com',
        addedBy: 'legacy',
        createdAt: Timestamp.now(),
      });
    });
    await assertFails(setDoc(doc(userADb, 'apps', 'legacy_app'), buildValidAppPayload('legacy_app', USER_A_UID)));
    await assertFails(getDoc(doc(userADb, 'users', USER_B_UID)));
  });

  it('11. Report status shortcutting by non-admin is blocked', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      const now = Timestamp.now();
      await setDoc(doc(db, 'apps', 'app_1', 'reviews', USER_B_UID), {
        appId: 'app_1',
        userId: USER_B_UID,
        userName: 'İstifadəçi B',
        rating: 4,
        comment: 'Normal rəy mətni.',
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: now,
        updatedAt: now,
      });
    });

    const userADb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userADb, 'reports', `app_1__${USER_B_UID}__${USER_A_UID}`), {
        appId: 'app_1',
        appName: 'Atlas Qeydlər',
        reviewUserId: USER_B_UID,
        reviewUserName: 'İstifadəçi B',
        reviewComment: 'Normal rəy mətni.',
        reporterId: USER_A_UID,
        reporterName: 'İstifadəçi A',
        reason: 'Saxta rəy',
        details: 'Test',
        status: 'resolved_deleted',
        adminNote: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('12. Oversized document ID and oversized comment are blocked', async () => {
    const userADb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertFails(
      setDoc(doc(userADb, 'apps', 'app_1', 'reviews', 'a'.repeat(300)), {
        appId: 'app_1',
        userId: USER_A_UID,
        userName: 'İstifadəçi A',
        rating: 5,
        comment: 'x'.repeat(2000),
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );
  });

  it('Positive: Verified Google Admin (oruc71049@gmail.com) can create/update app listing and cannot create secondary /admins', async () => {
    const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
      email: ADMIN_EMAIL,
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();
    await assertSucceeds(setDoc(doc(adminDb, 'apps', 'app_new'), buildValidAppPayload('app_new', ADMIN_UID)));
    await assertSucceeds(
      updateDoc(doc(adminDb, 'apps', 'app_new'), {
        version: '1.3.0',
        updatedAt: serverTimestamp(),
      }),
    );
    await assertFails(
      setDoc(doc(adminDb, 'admins', USER_A_UID), {
        uid: USER_A_UID,
        email: 'other@gmail.com',
        addedBy: ADMIN_UID,
        createdAt: serverTimestamp(),
      }),
    );
  });

  it('Positive: Verified User download receipt increments once, blocks repeat inflation, allows single review & edit & report', async () => {
    const userADb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();

    // Create own profile
    await assertSucceeds(
      setDoc(doc(userADb, 'users', USER_A_UID), {
        uid: USER_A_UID,
        displayName: 'Əli Məmmədov',
        email: 'usera@example.com',
        photoURL: 'https://example.com/a.jpg',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );

    // First-time atomic download + downloadCount +1
    const dlBatch = writeBatch(userADb);
    dlBatch.set(doc(userADb, 'apps', 'app_1', 'downloads', USER_A_UID), {
      appId: 'app_1',
      userId: USER_A_UID,
      version: '1.0.0',
      downloadedAt: serverTimestamp(),
      lastDownloadedAt: serverTimestamp(),
    });
    dlBatch.update(doc(userADb, 'apps', 'app_1'), { downloadCount: 1 });
    await assertSucceeds(dlBatch.commit());

    // Repeat download CANNOT increment downloadCount again
    await assertFails(updateDoc(doc(userADb, 'apps', 'app_1'), { downloadCount: 2 }));

    // Submit verified single review atomically
    const revBatch = writeBatch(userADb);
    revBatch.set(doc(userADb, 'apps', 'app_1', 'reviews', USER_A_UID), {
      appId: 'app_1',
      userId: USER_A_UID,
      userName: 'Əli Məmmədov',
      rating: 5,
      comment: 'Çox sürətli və stabil işləyir.',
      verifiedDownload: true,
      status: 'active',
      reportCount: 0,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    revBatch.update(doc(userADb, 'apps', 'app_1'), {
      ratingSum: 5,
      reviewCount: 1,
      avgRating: 5,
    });
    await assertSucceeds(revBatch.commit());

    // Edit own review rating 5 -> 4 atomically
    const editBatch = writeBatch(userADb);
    editBatch.update(doc(userADb, 'apps', 'app_1', 'reviews', USER_A_UID), {
      rating: 4,
      comment: 'Yenilənmiş rəy: yaxşı tətbiqdir.',
      userName: 'Əli Məmmədov',
      updatedAt: serverTimestamp(),
    });
    editBatch.update(doc(userADb, 'apps', 'app_1'), {
      ratingSum: 4,
      reviewCount: 1,
      avgRating: 4,
    });
    await assertSucceeds(editBatch.commit());

    // Delete own review atomically
    const delBatch = writeBatch(userADb);
    delBatch.delete(doc(userADb, 'apps', 'app_1', 'reviews', USER_A_UID));
    delBatch.update(doc(userADb, 'apps', 'app_1'), {
      ratingSum: 0,
      reviewCount: 0,
      avgRating: 0,
    });
    await assertSucceeds(delBatch.commit());
    assert.equal((await getDoc(doc(userADb, 'apps', 'app_1'))).data()?.reviewCount, 0);
  });

  it('Positive: Admin can delete reported review and delete app listing cleanly', async () => {
    await testEnv.withSecurityRulesDisabled(async (ctx) => {
      const db = ctx.firestore();
      const now = Timestamp.now();
      await setDoc(doc(db, 'apps', 'app_1', 'reviews', USER_B_UID), {
        appId: 'app_1',
        userId: USER_B_UID,
        userName: 'İstifadəçi B',
        rating: 1,
        comment: 'Spam reklam linki.',
        verifiedDownload: true,
        status: 'active',
        reportCount: 0,
        createdAt: now,
        updatedAt: now,
      });
    });

    const userADb = testEnv.authenticatedContext(USER_A_UID, {
      email: 'usera@example.com',
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();

    const reportId = `app_1__${USER_B_UID}__${USER_A_UID}`;
    await assertSucceeds(
      setDoc(doc(userADb, 'reports', reportId), {
        appId: 'app_1',
        appName: 'Atlas Qeydlər',
        reviewUserId: USER_B_UID,
        reviewUserName: 'İstifadəçi B',
        reviewComment: 'Spam reklam linki.',
        reporterId: USER_A_UID,
        reporterName: 'İstifadəçi A',
        reason: 'Spam və ya reklam',
        details: 'Şübhəli reklam mətni.',
        status: 'pending',
        adminNote: '',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }),
    );

    const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
      email: ADMIN_EMAIL,
      email_verified: true,
      firebase: { sign_in_provider: 'google.com' },
    }).firestore();

    const modBatch = writeBatch(adminDb);
    modBatch.delete(doc(adminDb, 'apps', 'app_1', 'reviews', USER_B_UID));
    modBatch.update(doc(adminDb, 'apps', 'app_1'), {
      ratingSum: 0,
      reviewCount: 0,
      avgRating: 0,
      updatedAt: serverTimestamp(),
    });
    modBatch.update(doc(adminDb, 'reports', reportId), {
      status: 'resolved_deleted',
      adminNote: 'Spam təsdiqləndi və silindi.',
      updatedAt: serverTimestamp(),
    });
    await assertSucceeds(modBatch.commit());
    await assertSucceeds(deleteDoc(doc(adminDb, 'apps', 'app_1')));
  });
});
